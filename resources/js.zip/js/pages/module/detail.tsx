import { PlaceholderPattern } from '@/components/ui/placeholder-pattern';
import InteractivePDFFlipBook from '@/components/InteractivePDFFlipBook';

import { PageProps as InertiaPageProps } from '@inertiajs/core';
import axios from 'axios';

import AppLayout from '@/layouts/app-layout';
import { type BreadcrumbItem } from '@/types';
import { Head, Link, usePage, router } from '@inertiajs/react';
import {
    BookOpen,
    FileText,
    Video,
    ClipboardList,
    Upload,
    Flame,
    Clock,
    CheckCircle,
    ArrowLeft,
    Download,
    Play,
    Globe,
    Target,
    BookOpenCheck,
    Lightbulb,
    PenTool,
    Calendar,
    AlertCircle,
    Trophy,
    X,
    Eye,
    Loader2
} from 'lucide-react';
import { useRef, useEffect, useState, useCallback, useMemo, memo } from 'react';
import toast from 'react-hot-toast';
import { useCustomToast } from '@/hooks/use-toast';

// TypeScript interfaces
interface ModuleData {
    id: number;
    title: string;
    description: string;
    color: string;
    progress: number;
    totalLessons: number;
    completedLessons: number;
    estimatedTime: string;
    difficulty: string;
    prerequisites: string[];
}

interface Video {
    id: number;
    title: string;
    platform: string;
    duration: string;
    thumbnail: string;
    watched: boolean;
    url?: string;
}

interface Link {
    id?: number;
    title: string;
    url: string;
    type: string;
    completed?: boolean;
}

interface ContentSection {
    title: string;
    description: string;
    points: number;
    completed: boolean;
}

interface CPContent extends ContentSection {
    content: string[];
}

interface ATPContent extends ContentSection {
    content: string[];
}

interface MateriContent extends ContentSection {
    fileName: string;
    fileSize: string;
    readProgress: number;
    canDownload: boolean;
    file_path: string;
    material_id: number;
}

interface PengayaanContent extends ContentSection {
    id?: number;
    videos: Video[];
    links: Link[];
}

interface QuizContent extends ContentSection {
    totalQuestions: number;
    timeLimit: number;
    attempts: number;
    maxAttempts: number;
    bestScore: number | null;
}

interface PraktikumSubmission {
    id: number;
    file_name: string;
    submitted_at: string;
    status: string;
    points_earned: number;
    score: number | null;
    feedback: string | null;
    is_graded: boolean;
    submission_time_info: {
        status: string;
        message: string;
        color: string;
    };
}

interface PraktikumContent extends ContentSection {
    deadline: string;
    deadline_formatted: string;
    has_custom_deadline: boolean;
    submitted: boolean;
    submissionFile: string | null;
    submission: PraktikumSubmission | null;
    tasks: string[];
    assignment_id: number;
}

interface ModuleContent {
    cp: CPContent;
    atp: ATPContent;
    materi: MateriContent;
    pengayaan: PengayaanContent;
    quiz: QuizContent;
    praktikum: PraktikumContent;
}

interface PageProps extends InertiaPageProps {
    moduleData: ModuleData;
    moduleContent: ModuleContent;
    breadcrumbs: BreadcrumbItem[];
}

// Utility function
const formatDeadline = (deadline: string): string => {
    const date = new Date(deadline);
    const now = new Date();
    const diff = date.getTime() - now.getTime();
    const days = Math.ceil(diff / (1000 * 60 * 60 * 24));

    if (days > 0) return `${days} hari lagi`;
    if (days === 0) return 'Hari ini';
    return `Terlambat ${Math.abs(days)} hari`;
};

// Modal Component
const Modal = memo(({ isOpen, onClose, title, children }: {
    isOpen: boolean;
    onClose: () => void;
    title: string;
    children: React.ReactNode
}) => {
    if (!isOpen) return null;

    return (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
            <div className="bg-white dark:bg-gray-800 rounded-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
                <div className="flex items-center justify-between p-4 md:p-6 border-b border-gray-200 dark:border-gray-700 sticky top-0 bg-white dark:bg-gray-800 z-10">
                    <h2 className="text-lg md:text-xl font-semibold text-gray-900 dark:text-white">{title}</h2>
                    <button
                        onClick={onClose}
                        className="p-2 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg transition-colors"
                        aria-label="Close modal"
                    >
                        <X className="h-5 w-5 text-gray-500" />
                    </button>
                </div>
                <div className="p-4 md:p-6">
                    {children}
                </div>
            </div>
        </div>
    );
});

Modal.displayName = 'Modal';

const SectionHeader = memo(({
    icon: Icon,
    title,
    description,
    points,
    completed,
    color
}: {
    icon: React.ElementType;
    title: string;
    description: string;
    points: number;
    completed: boolean;
    color: string;
}) => (
    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-4">
        <div className="flex items-center gap-3">
            <div className={`p-2 rounded-lg ${color} flex-shrink-0`}>
                <Icon className="h-5 w-5 text-white" />
            </div>
            <div className="min-w-0 flex-1">
                <h3 className="font-semibold text-gray-900 dark:text-white text-sm md:text-base">{title}</h3>
                <p className="text-xs md:text-sm text-gray-500 dark:text-gray-400 break-words whitespace-normal text-pretty">{description}</p>
            </div>
        </div>
        <div className="flex items-center gap-2 flex-shrink-0">
            {completed && <CheckCircle className="h-5 w-5 text-green-500" />}
            <div className="flex items-center gap-1.5 text-orange-600 dark:text-orange-400">
                <div className="relative inline-flex items-center justify-center w-5 h-5">
                    <Flame
                        size={20}
                        className="text-orange-500 relative z-10"
                        style={{
                            animation: "iconPulse 1s infinite ease-in-out",
                            filter: "drop-shadow(0 0 4px rgba(255, 153, 0, 0.8))"
                        }}
                    />
                    {[...Array(3)].map((_, i) => (
                        <div
                            key={i}
                            className="absolute bottom-0 rounded-full"
                            style={{
                                width: `${4 - i * 0.8}px`,
                                height: `${6 - i * 1.2}px`,
                                background: `radial-gradient(circle at bottom, ${i === 0 ? '#ffff66' : i === 1 ? '#ff9900' : '#ff6b00'} 0%, ${i === 0 ? '#ff9900' : '#ff3300'} 50%, transparent 80%)`,
                                animation: `fireWave ${0.6 + i * 0.2}s infinite ease-in-out ${i * 0.1}s`,
                                filter: `blur(${1.5 + i}px)`,
                                zIndex: 5 - i,
                            }}
                        />
                    ))}
                    <div className="absolute bottom-1 -left-0.5 w-1 h-2 rounded-full blur-[1px]" style={{ background: "linear-gradient(to top, #ff9900, #ff3300, transparent)", animation: "sideFire 0.7s infinite ease-in-out" }} />
                    <div className="absolute bottom-1 -right-0.5 w-1 h-2 rounded-full blur-[1px]" style={{ background: "linear-gradient(to top, #ff9900, #ff3300, transparent)", animation: "sideFire 0.7s infinite ease-in-out 0.35s" }} />
                    {[...Array(2)].map((_, i) => (
                        <div key={`spark-${i}`} className="absolute bottom-0 w-0.5 h-0.5 rounded-full" style={{ left: `${35 + i * 20}%`, background: i % 2 === 0 ? '#ffff66' : '#ff9900', animation: `sparkRise ${1 + i * 0.3}s infinite ease-out ${i * 0.3}s` }} />
                    ))}
                    <div className="absolute inset-0 rounded-full" style={{ background: "radial-gradient(circle, rgba(255, 153, 0, 0.4) 0%, transparent 70%)", animation: "fireGlow 1.5s infinite ease-in-out", filter: "blur(4px)" }} />
                    <style>{`
                        @keyframes fireWave { 0%, 100% { transform: translateY(0) scaleY(1) scaleX(1); opacity: 1; } 33% { transform: translateY(-6px) scaleY(1.3) scaleX(0.85); opacity: 0.9; } 66% { transform: translateY(-10px) scaleY(1.5) scaleX(0.75); opacity: 0.6; } }
                        @keyframes iconPulse { 0%, 100% { transform: scale(1); opacity: 1; } 50% { transform: scale(1.05); opacity: 0.95; } }
                        @keyframes sideFire { 0% { transform: translateY(0) scaleY(1) rotate(-5deg); opacity: 0.8; } 50% { transform: translateY(-8px) scaleY(1.4) rotate(-8deg); opacity: 0.5; } 100% { transform: translateY(-12px) scaleY(0.5) rotate(-12deg); opacity: 0; } }
                        @keyframes sparkRise { 0% { transform: translateY(0) translateX(0) scale(1); opacity: 1; } 50% { opacity: 0.7; } 100% { transform: translateY(-15px) scale(0.3); opacity: 0; } }
                        @keyframes fireGlow { 0%, 100% { opacity: 0.5; transform: scale(1); } 50% { opacity: 0.8; transform: scale(1.15); } }
                        @media (prefers-reduced-motion: reduce) { * { animation-duration: 0.01ms !important; animation-iteration-count: 1 !important; } }
                    `}</style>
                </div>
                <span className="text-sm font-medium">{points}</span>
            </div>
        </div>
    </div>
));

SectionHeader.displayName = 'SectionHeader';

// ✅ FIX 1: MateriCard sebagai komponen terpisah (BUKAN useMemo)
// Ini penting agar React bisa re-render + ResizeObserver di InteractivePDFFlipBook
// bisa mendeteksi perubahan layout saat isCompleted berubah
interface MateriCardProps {
    moduleContent: ModuleContent;
    completedMateri: boolean;
    moduleDataColor: string;
    handleDownload: () => void;
    handleMaterialComplete: () => void;
}

const MateriCard = memo(({
    moduleContent,
    completedMateri,
    moduleDataColor,
    handleDownload,
    handleMaterialComplete,
}: MateriCardProps) => (
    // ✅ FIX 2: overflow-hidden + min-w-0 mencegah flipbook bleed keluar card
    <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-4 md:p-6 overflow-hidden min-w-0">
        <SectionHeader
            icon={FileText}
            title={moduleContent.materi.title}
            description={moduleContent.materi.description}
            points={moduleContent.materi.points}
            completed={completedMateri}
            color={moduleDataColor}
        />

        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-4 bg-gray-50 dark:bg-gray-700 rounded-lg mb-4 gap-3">
            <div className="flex items-center gap-3 min-w-0 flex-1">
                <FileText className="h-8 w-8 text-red-500 flex-shrink-0" />
                <div className="min-w-0 flex-1">
                    <p className="font-medium text-gray-900 dark:text-white text-sm md:text-base truncate">
                        {moduleContent.materi.fileName}
                    </p>
                    <p className="text-xs md:text-sm text-gray-500 dark:text-gray-400">
                        {moduleContent.materi.fileSize}
                    </p>
                </div>
            </div>
            <button
                onClick={handleDownload}
                disabled={!moduleContent.materi.canDownload}
                className={`flex items-center gap-2 py-2 px-4 rounded-lg transition-colors text-sm whitespace-nowrap ${
                    moduleContent.materi.canDownload
                        ? 'bg-green-600 hover:bg-green-700 text-white'
                        : 'bg-gray-300 dark:bg-gray-600 text-gray-500 cursor-not-allowed'
                }`}
            >
                <Download className="h-4 w-4" />
                <span className="hidden sm:inline">Download</span>
            </button>
        </div>

        <div className="space-y-2 mb-4">
            <div className="flex justify-between text-sm">
                <span className="text-gray-600 dark:text-gray-400">Progress Membaca</span>
                <span className="text-gray-600 dark:text-gray-400">{moduleContent.materi.readProgress}%</span>
            </div>
            <div className="w-full bg-gray-200 dark:bg-gray-600 rounded-full h-2">
                <div
                    className="bg-green-500 h-2 rounded-full transition-all duration-300"
                    style={{ width: `${moduleContent.materi.readProgress}%` }}
                />
            </div>
        </div>

        {/* ✅ FIX 3: wrapper FlipBook pakai w-full overflow-hidden min-w-0 */}
        <div className="mb-4 w-full overflow-hidden min-w-0">
            <InteractivePDFFlipBook
                pdfUrl={`/storage/${moduleContent.materi.file_path}`}
                materialId={moduleContent.materi.material_id}
                onProgressUpdate={(progress) => {
                    console.log('Reading progress:', progress);
                }}
                onComplete={handleMaterialComplete}
                readProgress={moduleContent.materi.readProgress}
                isCompleted={completedMateri}
                preQuestions={[
                    {
                        id: 1,
                        question: "Apakah C++ adalah bahasa pemrograman?",
                        options: ["Ya", "Tidak"],
                        correct_answer: 0
                    },
                    {
                        id: 2,
                        question: "Apa yang Anda harapkan dari modul ini?",
                        options: [
                            "Memahami konsep dasar",
                            "Belajar praktik langsung",
                            "Menguasai teori",
                            "Semua di atas"
                        ],
                        correct_answer: 3
                    }
                ]}
            />
        </div>

        <div className="flex flex-col sm:flex-row gap-3">
            <button
                onClick={() => window.open(`/storage/${moduleContent.materi.file_path}`, '_blank')}
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg transition-colors text-sm md:text-base"
            >
                Buka di Tab Baru
            </button>
        </div>
    </div>
));

MateriCard.displayName = 'MateriCard';

export default function ModuleDetail() {
    const { moduleData, moduleContent, breadcrumbs, auth } = usePage<any>().props;
    const customToast = useCustomToast();

    const [state, setState] = useState({
        loading: false,
        completedSections: {
            cp: moduleContent.cp.completed,
            atp: moduleContent.atp.completed,
            materi: moduleContent.materi.completed,
        },
        userPoints: auth.user.point_fire,
        showPengayaanModal: false,
        showPraktikumModal: false,
        selectedFile: null as File | null,
        uploadProgress: 0,
        completedVideos: moduleContent.pengayaan.videos
            .filter((v: Video) => v.watched)
            .map((v: Video) => v.id),
        completedLinks: moduleContent.pengayaan.links
            .filter((l: Link) => l.completed)
            .map((l: Link) => l.id),
        showDeleteConfirm: false,
        isResubmitting: false,
        moduleProgress: moduleData.progress,
        completedLessons: moduleData.completedLessons,
        pdfViewMode: 'viewer' as 'viewer' | 'flipbook',
    });

    const updateStateOptimistically = useCallback((updates: Partial<typeof state>) => {
        setState(prev => ({ ...prev, ...updates }));
    }, []);

    const handleDeleteSubmission = useCallback(() => {
        if (!confirm('Apakah Anda yakin ingin menghapus file ini? Poin yang sudah didapat akan dikurangi.')) return;

        const toastId = toast.loading('Menghapus file...');
        setState(prev => ({ ...prev, loading: true }));

        router.delete(
            `/assignments/${moduleContent.praktikum.assignment_id}/submission`,
            {
                preserveScroll: true,
                onSuccess: (page) => {
                    const response = page.props.flash as any;
                    toast.dismiss(toastId);
                    if (response?.success) {
                        toast.success('🗑️ File berhasil dihapus!');
                        updateStateOptimistically({ userPoints: response.total_points });
                    }
                    router.reload({ only: ['moduleContent', 'auth'] });
                },
                onError: (errors) => {
                    toast.dismiss(toastId);
                    toast.error('❌ Gagal menghapus file. Silakan coba lagi.');
                },
                onFinish: () => setState(prev => ({ ...prev, loading: false }))
            }
        );
    }, [moduleContent.praktikum.assignment_id, updateStateOptimistically]);

    const handleResubmitAssignment = useCallback(async () => {
        if (!state.selectedFile) { toast.error('Pilih file terlebih dahulu'); return; }
        if (!confirm('Apakah Anda yakin ingin mengganti file? Poin akan dihitung ulang berdasarkan waktu pengumpulan saat ini.')) return;

        const toastId = toast.loading('Mengganti file...');
        setState(prev => ({ ...prev, loading: true, isResubmitting: true }));

        const formData = new FormData();
        formData.append('file', state.selectedFile);
        formData.append('notes', '');

        router.post(
            `/assignments/${moduleContent.praktikum.assignment_id}/resubmit`,
            formData as any,
            {
                preserveScroll: true,
                forceFormData: true,
                onSuccess: (page) => {
                    const response = page.props.flash as any;
                    toast.dismiss(toastId);
                    if (response?.success) {
                        toast.success('✅ File berhasil diganti!');
                        updateStateOptimistically({ selectedFile: null, showPraktikumModal: false, userPoints: response.total_points });
                    }
                    router.reload({ only: ['moduleContent', 'auth'] });
                },
                onError: () => { toast.dismiss(toastId); toast.error('❌ Gagal mengganti file.'); },
                onFinish: () => setState(prev => ({ ...prev, loading: false, uploadProgress: 0, isResubmitting: false }))
            }
        );
    }, [state.selectedFile, moduleContent.praktikum.assignment_id, updateStateOptimistically]);

    const handleUploadAssignment = useCallback(async () => {
        if (!state.selectedFile) { toast.error('Pilih file terlebih dahulu'); return; }
        if (moduleContent.praktikum.submitted) { toast.error('Tugas sudah dikumpulkan sebelumnya'); return; }

        const toastId = toast.loading('Mengupload tugas...');
        setState(prev => ({ ...prev, loading: true }));

        const formData = new FormData();
        formData.append('file', state.selectedFile);
        formData.append('notes', '');

        router.post(
            `/assignments/${moduleContent.praktikum.assignment_id}/submit`,
            formData as any,
            {
                preserveScroll: true,
                forceFormData: true,
                onSuccess: (page) => {
                    toast.dismiss(toastId);
                    toast.success(`🎉 Tugas berhasil dikumpulkan! +${moduleContent.praktikum.points} poin`, { duration: 4000 });
                    updateStateOptimistically({ selectedFile: null, showPraktikumModal: false, userPoints: state.userPoints + moduleContent.praktikum.points });
                    router.reload({ only: ['moduleContent', 'auth'] });
                },
                onError: () => { toast.dismiss(toastId); toast.error('❌ Gagal mengupload tugas.'); },
                onFinish: () => setState(prev => ({ ...prev, loading: false, uploadProgress: 0 }))
            }
        );
    }, [state.selectedFile, state.userPoints, moduleContent.praktikum, updateStateOptimistically]);

    const handleComplete = useCallback(async (type: 'cp' | 'learning_objective') => {
        if (state.loading) return;

        const sectionKey = type === 'cp' ? 'cp' : 'atp';
        const sectionPoints = moduleContent[sectionKey].points;

        updateStateOptimistically({
            completedSections: { ...state.completedSections, [sectionKey]: true },
            userPoints: state.userPoints + sectionPoints,
            completedLessons: state.completedLessons + 1,
        });

        toast.success(`🎉 Selamat! +${sectionPoints} poin`, { duration: 3000 });

        const endpoint = type === 'cp'
            ? `/modules/${moduleData.id}/cpmk/complete`
            : `/modules/${moduleData.id}/learning-objective/complete`;

        setState(prev => ({ ...prev, loading: true }));

        router.post(endpoint, {}, {
            preserveScroll: true,
            onSuccess: (page) => {
                const response = page.props.flash as any;
                if (response?.success) updateStateOptimistically({ userPoints: response.total_points });
                router.reload({ only: ['moduleData', 'moduleContent', 'auth'] });
            },
            onError: () => {
                updateStateOptimistically({
                    completedSections: { ...state.completedSections, [sectionKey]: false },
                    userPoints: state.userPoints,
                    completedLessons: state.completedLessons,
                });
                toast.error('❌ Terjadi kesalahan. Silakan coba lagi.');
            },
            onFinish: () => setState(prev => ({ ...prev, loading: false }))
        });
    }, [state.loading, state.completedSections, state.userPoints, state.completedLessons, moduleData.id, moduleContent, updateStateOptimistically]);

    const handleMaterialComplete = useCallback(() => {
        if (state.completedSections.materi) { toast.error('Materi sudah diselesaikan sebelumnya'); return; }

        const materiPoints = moduleContent.materi.points;
        updateStateOptimistically({
            completedSections: { ...state.completedSections, materi: true },
            userPoints: state.userPoints + materiPoints,
            completedLessons: state.completedLessons + 1,
        });

        toast.success(`🎉 Materi selesai! +${materiPoints} poin`, { duration: 3000 });
        setState(prev => ({ ...prev, loading: true }));

        router.post(`/materials/${moduleContent.materi.material_id}/complete`, {}, {
            preserveScroll: true,
            onSuccess: (page) => {
                const response = page.props.flash as any;
                if (response?.success) updateStateOptimistically({ userPoints: response.total_points });
                router.reload({ only: ['moduleData', 'moduleContent', 'auth'] });
            },
            onError: () => {
                updateStateOptimistically({
                    completedSections: { ...state.completedSections, materi: false },
                    userPoints: state.userPoints,
                    completedLessons: state.completedLessons,
                });
                toast.error('❌ Terjadi kesalahan. Silakan coba lagi.');
            },
            onFinish: () => setState(prev => ({ ...prev, loading: false }))
        });
    }, [state.completedSections.materi, state.userPoints, state.completedLessons, moduleContent.materi, updateStateOptimistically]);

    const handleDownload = useCallback(() => {
        if (!moduleContent.materi.canDownload) { toast.error('⚠️ Selesaikan membaca materi terlebih dahulu'); return; }
        toast.success('⬇️ Mengunduh file...');
        window.location.href = `/materials/${moduleContent.materi.material_id}/download`;
    }, [moduleContent.materi]);

    const handleFileSelect = useCallback((e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file) return;
        if (file.type !== 'application/pdf') { toast.error('❌ Hanya file PDF yang diperbolehkan'); return; }
        if (file.size > 10 * 1024 * 1024) { toast.error('❌ Ukuran file maksimal 10MB'); return; }
        setState(prev => ({ ...prev, selectedFile: file }));
        toast.success(`📁 File "${file.name}" dipilih`);
    }, []);

    const handleEnrichmentComplete = useCallback(async (itemId: number, itemType: 'video' | 'link', moduleId: number) => {
        if (state.loading) return;

        const pointsEarned = 5;
        updateStateOptimistically({
            completedVideos: itemType === 'video' ? [...state.completedVideos, itemId] : state.completedVideos,
            completedLinks: itemType === 'link' ? [...state.completedLinks, itemId] : state.completedLinks,
            userPoints: state.userPoints + pointsEarned,
        });

        toast.success(`✅ ${itemType === 'video' ? 'Video' : 'Link'} selesai! +${pointsEarned} poin`);
        setState(prev => ({ ...prev, loading: true }));

        router.post(`/enrichments/${itemId}/complete`, { type: itemType, module_id: moduleId }, {
            preserveScroll: true,
            onSuccess: (page) => {
                const response = page.props.flash as any;
                if (response?.success) updateStateOptimistically({ userPoints: response.total_points || state.userPoints });
                router.reload({ only: ['moduleData', 'moduleContent', 'auth'] });
            },
            onError: () => {
                updateStateOptimistically({
                    completedVideos: itemType === 'video' ? state.completedVideos.filter((id: number) => id !== Number(itemId)) : state.completedVideos,
                    completedLinks: itemType === 'link' ? state.completedLinks.filter((id: number) => id !== Number(itemId)) : state.completedLinks,
                    userPoints: state.userPoints,
                });
                toast.error('❌ Terjadi kesalahan. Silakan coba lagi.');
            },
            onFinish: () => setState(prev => ({ ...prev, loading: false }))
        });
    }, [state.loading, state.completedVideos, state.completedLinks, state.userPoints, updateStateOptimistically]);

    const CPCard = useMemo(() => (
        <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-4 md:p-6">
            <SectionHeader
                icon={Target}
                title={moduleContent.cp.title}
                description={moduleContent.cp.description}
                points={moduleContent.cp.points}
                completed={state.completedSections.cp}
                color={moduleData.color}
            />
            <div className="space-y-3">
                {moduleContent.cp.content.map((item: string, index: number) => (
                    <div key={index} className="flex items-start gap-3">
                        <Target className="h-4 w-4 text-blue-500 mt-0.5 flex-shrink-0" />
                        <span className="text-sm text-gray-700 dark:text-gray-300">{item}</span>
                    </div>
                ))}
                <button
                    onClick={() => handleComplete('cp')}
                    disabled={state.loading || state.completedSections.cp}
                    className={`w-full mt-4 py-2 px-4 rounded-lg transition-colors flex items-center justify-center gap-2 text-sm md:text-base ${
                        state.completedSections.cp ? 'bg-green-600 text-white cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700 text-white'
                    }`}
                >
                    {state.loading ? <><Loader2 className="h-4 w-4 animate-spin" />Processing...</> : state.completedSections.cp ? <><CheckCircle className="h-4 w-4" />Selesai</> : 'Tandai Selesai'}
                </button>
            </div>
        </div>
    ), [moduleContent.cp, state.completedSections.cp, state.loading, moduleData.color, handleComplete]);

    const ATPCard = useMemo(() => (
        <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-4 md:p-6">
            <SectionHeader
                icon={BookOpenCheck}
                title={moduleContent.atp.title}
                description={moduleContent.atp.description}
                points={moduleContent.atp.points}
                completed={state.completedSections.atp}
                color={moduleData.color}
            />
            <div className="space-y-3">
                {moduleContent.atp.content.map((item: string, index: number) => (
                    <div key={index} className="flex items-start gap-3">
                        <div className="flex items-center justify-center w-6 h-6 rounded-full bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-400 text-xs font-semibold flex-shrink-0">
                            {index + 1}
                        </div>
                        <span className="text-sm text-gray-700 dark:text-gray-300">{item}</span>
                    </div>
                ))}
                <button
                    onClick={() => handleComplete('learning_objective')}
                    disabled={state.loading || state.completedSections.atp}
                    className={`w-full mt-4 py-2 px-4 rounded-lg transition-colors flex items-center justify-center gap-2 text-sm md:text-base ${
                        state.completedSections.atp ? 'bg-green-600 text-white cursor-not-allowed' : 'bg-blue-600 hover:bg-blue-700 text-white'
                    }`}
                >
                    {state.loading ? <><Loader2 className="h-4 w-4 animate-spin" />Processing...</> : state.completedSections.atp ? <><CheckCircle className="h-4 w-4" />Selesai</> : 'Tandai Selesai'}
                </button>
            </div>
        </div>
    ), [moduleContent.atp, state.completedSections.atp, state.loading, moduleData.color, handleComplete]);

    return (
        <AppLayout breadcrumbs={breadcrumbs}>
            <Head title={`${moduleData.title} - Module Detail`} />

            {/* ✅ FIX 4: overflow-x-hidden (bukan auto) mencegah horizontal scroll akibat flipbook */}
            <div className="flex h-full flex-1 flex-col gap-6 rounded-xl p-4 overflow-x-hidden">
                {/* Module Header */}
                <div className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-gray-800 dark:to-gray-700 p-6 rounded-xl">
                    <div className="flex items-start gap-4">
                        <Link
                            href="/dashboard"
                            className="flex items-center gap-2 text-blue-600 dark:text-blue-400 hover:text-blue-800 dark:hover:text-blue-300 transition-colors"
                        >
                            <ArrowLeft className="h-5 w-5" />
                            <span>Kembali ke Dashboard</span>
                        </Link>
                    </div>

                    <div className="flex items-start justify-between mt-4">
                        <div className="flex-1">
                            <div className="flex items-center gap-3 mb-2">
                                <div className={`p-3 rounded-lg ${moduleData.color}`}>
                                    <BookOpen className="h-6 w-6 text-white" />
                                </div>
                                <span className="text-sm font-medium text-gray-600 dark:text-gray-400">Modul {moduleData.id}</span>
                            </div>
                            <h1 className="text-2xl font-bold text-gray-900 dark:text-white mb-2">{moduleData.title}</h1>
                            <p className="text-gray-600 dark:text-gray-300 mb-4">{moduleData.description}</p>
                            <div className="flex flex-wrap gap-4 text-sm">
                                <div className="flex items-center gap-2">
                                    <Clock className="h-4 w-4 text-gray-500" />
                                    <span className="text-gray-600 dark:text-gray-400">{moduleData.estimatedTime}</span>
                                </div>
                                <div className="flex items-center gap-2">
                                    <Trophy className="h-4 w-4 text-gray-500" />
                                    <span className="text-gray-600 dark:text-gray-400">{moduleData.difficulty}</span>
                                </div>
                                <div className="flex items-center gap-2">
                                    <BookOpenCheck className="h-4 w-4 text-gray-500" />
                                    <span className="text-gray-600 dark:text-gray-400">{moduleData.completedLessons}/{moduleData.totalLessons} lessons</span>
                                </div>
                            </div>
                        </div>

                        <div className="flex flex-col items-center">
                            <div className="relative w-20 h-20">
                                <svg className="w-20 h-20 transform -rotate-90">
                                    <circle cx="40" cy="40" r="36" stroke="currentColor" strokeWidth="8" fill="transparent" className="text-gray-200 dark:text-gray-700" />
                                    <circle cx="40" cy="40" r="36" stroke="currentColor" strokeWidth="8" fill="transparent"
                                        strokeDasharray={`${2 * Math.PI * 36}`}
                                        strokeDashoffset={`${2 * Math.PI * 36 * (1 - moduleData.progress / 100)}`}
                                        className="text-green-500 transition-all duration-300"
                                    />
                                </svg>
                                <div className="absolute inset-0 flex items-center justify-center">
                                    <span className="text-sm font-bold text-gray-900 dark:text-white">{moduleData.progress}%</span>
                                </div>
                            </div>
                            <span className="text-xs text-gray-500 dark:text-gray-400 mt-2">Progress</span>
                        </div>
                    </div>
                </div>

                {/* ✅ FIX 5: Content Grid dengan overflow-hidden + min-w-0 */}
                <div className="grid gap-6 overflow-hidden min-w-0">
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        {CPCard}
                        {ATPCard}
                    </div>

                    {/* ✅ FIX 6: MateriCard kini komponen biasa, bukan useMemo,
                        sehingga isCompleted berubah → re-render → ResizeObserver trigger */}
                    <MateriCard
                        moduleContent={moduleContent}
                        completedMateri={state.completedSections.materi}
                        moduleDataColor={moduleData.color}
                        handleDownload={handleDownload}
                        handleMaterialComplete={handleMaterialComplete}
                    />

                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                        {/* Pengayaan Card */}
                        <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6">
                            <SectionHeader
                                icon={Lightbulb}
                                title={moduleContent.pengayaan.title}
                                description={moduleContent.pengayaan.description}
                                points={moduleContent.pengayaan.points}
                                completed={moduleContent.pengayaan.completed}
                                color={moduleData.color}
                            />
                            <div className="space-y-3 mb-4">
                                <p className="text-sm text-gray-600 dark:text-gray-400">{moduleContent.pengayaan.videos.length} video pembelajaran</p>
                                <p className="text-sm text-gray-600 dark:text-gray-400">{moduleContent.pengayaan.links.length} sumber tambahan</p>
                            </div>
                            <button
                                onClick={() => setState(prev => ({ ...prev, showPengayaanModal: true }))}
                                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg transition-colors flex items-center justify-center gap-2"
                            >
                                <Eye className="h-4 w-4" />
                                Lihat Detail
                            </button>
                        </div>

                        {/* Quiz Card */}
                        <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6">
                            <SectionHeader
                                icon={ClipboardList}
                                title={moduleContent.quiz.title}
                                description={moduleContent.quiz.description}
                                points={moduleContent.quiz.points}
                                completed={moduleContent.quiz.completed}
                                color={moduleData.color}
                            />
                            <div className="grid grid-cols-2 gap-4 mb-4">
                                <div className="text-center p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                                    <p className="text-2xl font-bold text-gray-900 dark:text-white">{moduleContent.quiz.totalQuestions}</p>
                                    <p className="text-sm text-gray-500 dark:text-gray-400">Soal</p>
                                </div>
                                <div className="text-center p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                                    <p className="text-2xl font-bold text-gray-900 dark:text-white">{moduleContent.quiz.timeLimit}</p>
                                    <p className="text-sm text-gray-500 dark:text-gray-400">Menit</p>
                                </div>
                            </div>
                            <div className="flex items-center justify-between text-sm mb-4">
                                <span className="text-gray-600 dark:text-gray-400">Percobaan: {moduleContent.quiz.attempts}/{moduleContent.quiz.maxAttempts}</span>
                                {moduleContent.quiz.bestScore && (
                                    <span className="text-green-600 dark:text-green-400 font-medium">Skor: {moduleContent.quiz.bestScore}/100</span>
                                )}
                            </div>
                            <Link
                                href={route('quiz.show', { id: moduleData.id })}
                                className="w-full bg-green-600 hover:bg-green-700 text-white py-2 px-4 rounded-lg transition-colors flex items-center justify-center gap-2"
                            >
                                <PenTool className="h-4 w-4" />
                                Mulai Quiz
                            </Link>
                        </div>

                        {/* Praktikum Card */}
                        <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-6">
                            <SectionHeader
                                icon={Upload}
                                title={moduleContent.praktikum.title}
                                description={moduleContent.praktikum.description}
                                points={moduleContent.praktikum.points}
                                completed={moduleContent.praktikum.completed}
                                color={moduleData.color}
                            />
                            <div className={`p-3 rounded-lg border mb-4 ${
                                formatDeadline(moduleContent.praktikum.deadline).includes('Terlambat')
                                    ? 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800'
                                    : 'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800'
                            }`}>
                                <div className="flex items-center gap-2">
                                    <Calendar className={`h-4 w-4 ${formatDeadline(moduleContent.praktikum.deadline).includes('Terlambat') ? 'text-red-500' : 'text-blue-500'}`} />
                                    <span className={`text-sm font-medium ${formatDeadline(moduleContent.praktikum.deadline).includes('Terlambat') ? 'text-red-700 dark:text-red-400' : 'text-blue-700 dark:text-blue-400'}`}>
                                        {formatDeadline(moduleContent.praktikum.deadline)}
                                    </span>
                                </div>
                            </div>
                            <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">{moduleContent.praktikum.tasks.length} tugas praktikum</p>
                            <button
                                onClick={() => setState(prev => ({ ...prev, showPraktikumModal: true }))}
                                className="w-full bg-orange-600 hover:bg-orange-700 text-white py-2 px-4 rounded-lg transition-colors flex items-center justify-center gap-2"
                            >
                                <Eye className="h-4 w-4" />
                                Lihat Detail
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            {/* Pengayaan Modal */}
            {state.showPengayaanModal && (
                <Modal
                    isOpen={state.showPengayaanModal}
                    onClose={() => setState(prev => ({ ...prev, showPengayaanModal: false }))}
                    title="Pengayaan & Sumber Tambahan"
                >
                    <div className="space-y-6">
                        {moduleContent.pengayaan.videos.length > 0 && (
                            <div>
                                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Video Pembelajaran</h3>
                                <div className="space-y-4">
                                    {moduleContent.pengayaan.videos.map((video: any) => (
                                        <div key={video.id} className="border border-gray-200 dark:border-gray-700 rounded-lg p-4 hover:border-blue-500 transition-colors">
                                            <div className="flex items-start gap-4">
                                                <div className="relative flex-shrink-0">
                                                    <div className="w-32 h-24 bg-gray-300 dark:bg-gray-600 rounded overflow-hidden">
                                                        <img src={video.thumbnail} alt={video.title} className="w-full h-full object-cover" onError={(e) => { e.currentTarget.src = 'https://via.placeholder.com/320x240?text=Video'; }} />
                                                    </div>
                                                    {!video.watched && (
                                                        <div className="absolute inset-0 flex items-center justify-center">
                                                            <div className="bg-black bg-opacity-50 rounded-full p-3"><Play className="h-6 w-6 text-white" /></div>
                                                        </div>
                                                    )}
                                                </div>
                                                <div className="flex-1">
                                                    <h4 className="font-medium text-gray-900 dark:text-white mb-2">{video.title}</h4>
                                                    <div className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400 mb-3">
                                                        <Video className="h-4 w-4" /><span>{video.platform}</span><span>•</span><Clock className="h-4 w-4" /><span>{video.duration}</span>
                                                    </div>
                                                    <div className="flex gap-3">
                                                        <a href={video.url || '#'} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm transition-colors">
                                                            <Play className="h-4 w-4" />Tonton Video
                                                        </a>
                                                        {!state.completedVideos.includes(video.id) && (
                                                            <button onClick={() => handleEnrichmentComplete(video.id, 'video', moduleContent.pengayaan.id || moduleData.id)} disabled={state.loading} className="flex items-center gap-2 bg-green-600 hover:bg-green-700 disabled:bg-gray-400 text-white px-4 py-2 rounded-lg text-sm transition-colors">
                                                                {state.loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <><CheckCircle className="h-4 w-4" />Tandai Selesai</>}
                                                            </button>
                                                        )}
                                                        {state.completedVideos.includes(video.id) && (
                                                            <div className="flex items-center gap-2 text-green-600 dark:text-green-400 px-4 py-2"><CheckCircle className="h-4 w-4" /><span className="text-sm font-medium">Selesai</span></div>
                                                        )}
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}

                        {moduleContent.pengayaan.links.length > 0 && (
                            <div>
                                <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-4">Sumber Tambahan</h3>
                                <div className="space-y-3">
                                    {moduleContent.pengayaan.links.map((link: any, index: number) => (
                                        <div key={index} className="border border-gray-200 dark:border-gray-700 rounded-lg p-4 hover:border-blue-500 transition-colors">
                                            <div className="flex items-center justify-between">
                                                <div className="flex items-center gap-3 flex-1">
                                                    <div className="p-2 bg-blue-100 dark:bg-blue-900/30 rounded-lg"><Globe className="h-5 w-5 text-blue-600 dark:text-blue-400" /></div>
                                                    <div className="flex-1">
                                                        <h4 className="font-medium text-gray-900 dark:text-white">{link.title}</h4>
                                                        <p className="text-sm text-gray-500 dark:text-gray-400">{link.type}</p>
                                                    </div>
                                                </div>
                                                <div className="flex gap-3">
                                                    <a href={link.url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm transition-colors">
                                                        <Globe className="h-4 w-4" />Buka Link
                                                    </a>
                                                    {!state.completedLinks.includes(link.id!) && link.id && (
                                                        <button onClick={() => handleEnrichmentComplete(link.id!, 'link', moduleContent.pengayaan.id || moduleData.id)} disabled={state.loading} className="flex items-center gap-2 bg-green-600 hover:bg-green-700 disabled:bg-gray-400 text-white px-4 py-2 rounded-lg text-sm transition-colors">
                                                            {state.loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <><CheckCircle className="h-4 w-4" />Tandai Selesai</>}
                                                        </button>
                                                    )}
                                                    {state.completedLinks.includes(link.id!) && (
                                                        <div className="flex items-center gap-2 text-green-600 dark:text-green-400 px-4 py-2"><CheckCircle className="h-4 w-4" /><span className="text-sm font-medium">Selesai</span></div>
                                                    )}
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        )}

                        {moduleContent.pengayaan.videos.length === 0 && moduleContent.pengayaan.links.length === 0 && (
                            <div className="text-center py-8">
                                <AlertCircle className="h-12 w-12 text-gray-400 mx-auto mb-3" />
                                <p className="text-gray-500 dark:text-gray-400">Belum ada materi pengayaan yang tersedia</p>
                            </div>
                        )}
                    </div>
                    <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-700">
                        <button onClick={() => setState(prev => ({ ...prev, showPengayaanModal: false }))} className="w-full bg-gray-600 hover:bg-gray-700 text-white py-2 px-4 rounded-lg transition-colors">Tutup</button>
                    </div>
                </Modal>
            )}

            {/* Praktikum Modal */}
            {state.showPraktikumModal && (
                <Modal
                    isOpen={state.showPraktikumModal}
                    onClose={() => setState(prev => ({ ...prev, showPraktikumModal: false, selectedFile: null }))}
                    title="Detail Praktikum"
                >
                    <div className="space-y-6">
                        <div className={`p-4 rounded-lg border ${formatDeadline(moduleContent.praktikum.deadline).includes('Terlambat') ? 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800' : 'bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800'}`}>
                            <div className="flex items-center gap-2 mb-2">
                                <Calendar className={`h-5 w-5 ${formatDeadline(moduleContent.praktikum.deadline).includes('Terlambat') ? 'text-red-500' : 'text-blue-500'}`} />
                                <span className={`font-semibold ${formatDeadline(moduleContent.praktikum.deadline).includes('Terlambat') ? 'text-red-700 dark:text-red-400' : 'text-blue-700 dark:text-blue-400'}`}>
                                    Deadline: {moduleContent.praktikum.deadline_formatted}
                                </span>
                            </div>
                            <p className={`text-sm ${formatDeadline(moduleContent.praktikum.deadline).includes('Terlambat') ? 'text-red-600 dark:text-red-500' : 'text-blue-600 dark:text-blue-500'}`}>
                                {formatDeadline(moduleContent.praktikum.deadline)}
                            </p>
                            {moduleContent.praktikum.has_custom_deadline && (
                                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">ⓘ Deadline khusus untuk kelas Anda</p>
                            )}
                        </div>

                        <div>
                            <h4 className="font-medium text-gray-900 dark:text-white mb-4">Daftar Tugas:</h4>
                            <div className="space-y-3">
                                {moduleContent.praktikum.tasks.map((task: string, index: number) => (
                                    <div key={index} className="flex items-start gap-3 p-3 bg-gray-50 dark:bg-gray-700 rounded-lg">
                                        <div className="flex items-center justify-center w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-400 text-sm font-semibold flex-shrink-0">{index + 1}</div>
                                        <p className="text-gray-900 dark:text-white flex-1">{task}</p>
                                    </div>
                                ))}
                            </div>
                        </div>

                        {moduleContent.praktikum.submitted && moduleContent.praktikum.submission ? (
                            <div className="space-y-4">
                                <div className="p-4 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg">
                                    <div className="flex items-start justify-between mb-3">
                                        <div className="flex items-center gap-3 flex-1">
                                            <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0" />
                                            <div>
                                                <p className="text-green-700 dark:text-green-400 font-medium">Tugas sudah dikumpulkan</p>
                                                <p className="text-sm text-green-600 dark:text-green-500 mt-1">File: {moduleContent.praktikum.submission.file_name}</p>
                                            </div>
                                        </div>
                                        <div className="flex items-center gap-2 text-orange-600 dark:text-orange-400">
                                            <Flame className="h-4 w-4" />
                                            <span className="text-sm font-medium">+{moduleContent.praktikum.submission.points_earned}</span>
                                        </div>
                                    </div>
                                    <div className="flex items-center gap-2 text-sm">
                                        <Clock className="h-4 w-4 text-gray-500" />
                                        <span className="text-gray-600 dark:text-gray-400">Dikumpulkan: {moduleContent.praktikum.submission.submitted_at}</span>
                                        <span className={`ml-2 px-2 py-1 rounded-full text-xs font-medium ${
                                            moduleContent.praktikum.submission.submission_time_info.color === 'green' ? 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400'
                                            : moduleContent.praktikum.submission.submission_time_info.color === 'red' ? 'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400'
                                            : 'bg-blue-100 dark:bg-blue-900/30 text-blue-700 dark:text-blue-400'
                                        }`}>
                                            {moduleContent.praktikum.submission.submission_time_info.message}
                                        </span>
                                    </div>
                                </div>

                                {moduleContent.praktikum.submission.is_graded ? (
                                    <div className="p-4 bg-gradient-to-r from-purple-50 to-blue-50 dark:from-purple-900/20 dark:to-blue-900/20 border border-purple-200 dark:border-purple-800 rounded-lg">
                                        <div className="flex items-start gap-3 mb-4">
                                            <div className="p-2 bg-purple-100 dark:bg-purple-900/50 rounded-lg"><Trophy className="h-5 w-5 text-purple-600 dark:text-purple-400" /></div>
                                            <div className="flex-1">
                                                <h4 className="font-semibold text-gray-900 dark:text-white mb-1">Hasil Penilaian</h4>
                                                <p className="text-sm text-gray-600 dark:text-gray-400">Tugas Anda sudah dinilai oleh dosen</p>
                                            </div>
                                        </div>
                                        <div className="grid grid-cols-2 gap-4 mb-4">
                                            <div className="bg-white dark:bg-gray-800 rounded-lg p-4 text-center border border-purple-200 dark:border-purple-700">
                                                <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Nilai</p>
                                                <p className={`text-3xl font-bold ${(moduleContent.praktikum.submission.score || 0) >= 80 ? 'text-green-600 dark:text-green-400' : (moduleContent.praktikum.submission.score || 0) >= 60 ? 'text-blue-600 dark:text-blue-400' : 'text-orange-600 dark:text-orange-400'}`}>
                                                    {moduleContent.praktikum.submission.score || 0}
                                                </p>
                                                <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">/ 100</p>
                                            </div>
                                            <div className="bg-white dark:bg-gray-800 rounded-lg p-4 text-center border border-purple-200 dark:border-purple-700">
                                                <p className="text-sm text-gray-500 dark:text-gray-400 mb-1">Grade</p>
                                                <p className={`text-3xl font-bold ${(moduleContent.praktikum.submission.score || 0) >= 80 ? 'text-green-600 dark:text-green-400' : (moduleContent.praktikum.submission.score || 0) >= 60 ? 'text-blue-600 dark:text-blue-400' : 'text-orange-600 dark:text-orange-400'}`}>
                                                    {(moduleContent.praktikum.submission.score || 0) >= 80 ? 'A' : (moduleContent.praktikum.submission.score || 0) >= 70 ? 'B' : (moduleContent.praktikum.submission.score || 0) >= 60 ? 'C' : (moduleContent.praktikum.submission.score || 0) >= 50 ? 'D' : 'E'}
                                                </p>
                                            </div>
                                        </div>
                                        {moduleContent.praktikum.submission.feedback && (
                                            <div className="bg-white dark:bg-gray-800 rounded-lg p-4 border border-purple-200 dark:border-purple-700">
                                                <div className="flex items-start gap-2 mb-2">
                                                    <PenTool className="h-4 w-4 text-purple-600 dark:text-purple-400 mt-0.5 flex-shrink-0" />
                                                    <p className="font-medium text-gray-900 dark:text-white text-sm">Feedback Dosen:</p>
                                                </div>
                                                <p className="text-sm text-gray-700 dark:text-gray-300 whitespace-pre-wrap">{moduleContent.praktikum.submission.feedback}</p>
                                            </div>
                                        )}
                                    </div>
                                ) : (
                                    <div className="p-4 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg">
                                        <div className="flex items-center gap-2">
                                            <AlertCircle className="h-5 w-5 text-yellow-600 dark:text-yellow-400" />
                                            <p className="text-sm text-yellow-700 dark:text-yellow-400">Tugas Anda sedang dalam proses penilaian oleh dosen</p>
                                        </div>
                                    </div>
                                )}

                                {!moduleContent.praktikum.submission.is_graded && (
                                    <div>
                                        <h4 className="font-medium text-gray-900 dark:text-white mb-3">Ganti File (Opsional):</h4>
                                        <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-6 text-center">
                                            <Upload className="h-12 w-12 text-gray-400 mx-auto mb-3" />
                                            <p className="text-gray-600 dark:text-gray-400 mb-2">{state.selectedFile ? state.selectedFile.name : 'Pilih file baru untuk mengganti (PDF, max 10MB)'}</p>
                                            <p className="text-sm text-orange-600 dark:text-orange-400 mb-4">⚠️ Poin akan dihitung ulang berdasarkan waktu pengumpulan baru</p>
                                            {state.uploadProgress > 0 && state.uploadProgress < 100 && (
                                                <div className="w-full bg-gray-200 rounded-full h-2 mb-4"><div className="bg-blue-600 h-2 rounded-full transition-all duration-300" style={{ width: `${state.uploadProgress}%` }} /></div>
                                            )}
                                            <input type="file" accept=".pdf" onChange={handleFileSelect} className="hidden" id="file-reupload" />
                                            <label htmlFor="file-reupload" className="bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg transition-colors cursor-pointer inline-block">Pilih File Baru</label>
                                        </div>
                                    </div>
                                )}

                                {moduleContent.praktikum.submission.is_graded && (
                                    <div className="p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
                                        <div className="flex items-start gap-2">
                                            <AlertCircle className="h-5 w-5 text-blue-600 dark:text-blue-400 mt-0.5 flex-shrink-0" />
                                            <div className="flex-1">
                                                <p className="text-sm text-blue-700 dark:text-blue-400 font-medium mb-1">Tugas sudah dinilai</p>
                                                <p className="text-sm text-blue-600 dark:text-blue-500">Anda tidak dapat menghapus atau mengganti file yang sudah dinilai oleh dosen.</p>
                                            </div>
                                        </div>
                                    </div>
                                )}

                                <div className="flex gap-3 pt-4">
                                    <button onClick={() => setState(prev => ({ ...prev, showPraktikumModal: false, selectedFile: null }))} className="flex-1 bg-gray-600 hover:bg-gray-700 text-white py-2 px-4 rounded-lg transition-colors">Tutup</button>
                                    {!moduleContent.praktikum.submission.is_graded && (
                                        <>
                                            <button onClick={handleDeleteSubmission} disabled={state.loading} className="flex-1 bg-red-600 hover:bg-red-700 disabled:bg-gray-400 text-white py-2 px-4 rounded-lg transition-colors flex items-center justify-center gap-2">
                                                {state.loading && !state.isResubmitting ? <><Loader2 className="h-4 w-4 animate-spin" />Menghapus...</> : <><X className="h-4 w-4" />Hapus File</>}
                                            </button>
                                            {state.selectedFile && (
                                                <button onClick={handleResubmitAssignment} disabled={state.loading} className="flex-1 bg-orange-600 hover:bg-orange-700 disabled:bg-gray-400 text-white py-2 px-4 rounded-lg transition-colors flex items-center justify-center gap-2">
                                                    {state.loading && state.isResubmitting ? <><Loader2 className="h-4 w-4 animate-spin" />Mengganti...</> : <><Upload className="h-4 w-4" />Ganti File</>}
                                                </button>
                                            )}
                                        </>
                                    )}
                                </div>
                            </div>
                        ) : (
                            <div>
                                <h4 className="font-medium text-gray-900 dark:text-white mb-4">Upload Laporan:</h4>
                                <div className="border-2 border-dashed border-gray-300 dark:border-gray-600 rounded-lg p-6 text-center">
                                    <Upload className="h-12 w-12 text-gray-400 mx-auto mb-3" />
                                    <p className="text-gray-600 dark:text-gray-400 mb-2">{state.selectedFile ? state.selectedFile.name : 'Pilih file PDF (max 10MB)'}</p>
                                    {state.uploadProgress > 0 && state.uploadProgress < 100 && (
                                        <div className="w-full bg-gray-200 rounded-full h-2 mb-4"><div className="bg-blue-600 h-2 rounded-full transition-all duration-300" style={{ width: `${state.uploadProgress}%` }} /></div>
                                    )}
                                    <input type="file" accept=".pdf" onChange={handleFileSelect} className="hidden" id="file-upload" />
                                    <label htmlFor="file-upload" className="bg-blue-600 hover:bg-blue-700 text-white py-2 px-4 rounded-lg transition-colors cursor-pointer inline-block">Pilih File</label>
                                </div>
                                <div className="flex gap-3 pt-4">
                                    <button onClick={() => setState(prev => ({ ...prev, showPraktikumModal: false, selectedFile: null }))} className="flex-1 bg-gray-600 hover:bg-gray-700 text-white py-2 px-4 rounded-lg transition-colors">Tutup</button>
                                    <button onClick={handleUploadAssignment} disabled={!state.selectedFile || state.loading} className="flex-1 bg-orange-600 hover:bg-orange-700 disabled:bg-gray-400 text-white py-2 px-4 rounded-lg transition-colors flex items-center justify-center gap-2">
                                        {state.loading ? <><Loader2 className="h-4 w-4 animate-spin" />Uploading...</> : <><Upload className="h-4 w-4" />Upload Laporan</>}
                                    </button>
                                </div>
                            </div>
                        )}
                    </div>
                </Modal>
            )}
        </AppLayout>
    );
}
