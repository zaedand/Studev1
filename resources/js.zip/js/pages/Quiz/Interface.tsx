import { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { router } from '@inertiajs/react';
import toast, { Toaster } from 'react-hot-toast';
import {
    Clock, ChevronLeft, ChevronRight, Flag, AlertTriangle,
    CheckCircle, Circle, Shield, Send
} from 'lucide-react';

interface Question {
    id: number;
    question: string;
    options: { A: string; B: string; C: string; D: string };
}

interface QuizInterfaceProps {
    module: { id: number; title: string; color: string };
    questions: Question[];
    quizConfig: {
        time_limit: number;
        total_questions: number;
        session_id: string;
        attempt_number: number;
        max_attempts: number;
    };
}

export default function Interface({ module, questions, quizConfig }: QuizInterfaceProps) {
    const [currentQuestion, setCurrentQuestion]     = useState(0);
    const [answers, setAnswers]                     = useState<Record<number, string>>({});
    const [timeLeft, setTimeLeft]                   = useState(quizConfig.time_limit * 60);
    const [isSubmitting, setIsSubmitting]           = useState(false);
    const [showConfirmSubmit, setShowConfirmSubmit] = useState(false);
    const [showIncomplete, setShowIncomplete]       = useState(false);
    const [isTimeUp, setIsTimeUp]                   = useState(false);
    const [tabViolations, setTabViolations]         = useState(0);
    const [showCheatWarning, setShowCheatWarning]   = useState(false);
    const [cheatMsg, setCheatMsg]                   = useState('');
    const [isPageVisible, setIsPageVisible]         = useState(true);

    const timerRef        = useRef<ReturnType<typeof setInterval> | null>(null);
    const submitCalledRef = useRef(false);

    const answeredCount      = useMemo(() => Object.keys(answers).length, [answers]);
    const isAllAnswered      = useMemo(() => answeredCount === questions.length, [answeredCount, questions.length]);
    const progressPercentage = useMemo(() => (answeredCount / questions.length) * 100, [answeredCount, questions.length]);

    const unansweredNums = useMemo(
        () => questions.filter(q => !answers[q.id]).map((_, i) => i + 1),
        [questions, answers]
    );

    // ── Anti-cheat: tab switch ──────────────────────────────
    useEffect(() => {
        const onVisibility = () => {
            if (document.visibilityState === 'hidden' && !isSubmitting && !isTimeUp) {
                setTabViolations(n => {
                    const next = n + 1;
                    setCheatMsg(`⚠️ Peringatan #${next}: Berpindah tab/window terdeteksi!`);
                    setShowCheatWarning(true);
                    toast.error(`Peringatan berpindah tab (${next}x)`, { duration: 4000, icon: '🚨' });
                    return next;
                });
                setIsPageVisible(false);
            } else {
                setIsPageVisible(true);
            }
        };
        document.addEventListener('visibilitychange', onVisibility);
        return () => document.removeEventListener('visibilitychange', onVisibility);
    }, [isSubmitting, isTimeUp]);

    // ── Anti-cheat: right-click & devtools shortcuts ────────
    useEffect(() => {
        const onCtx  = (e: MouseEvent) => { e.preventDefault(); };
        const onKey  = (e: KeyboardEvent) => {
            if (
                e.key === 'F12' ||
                (e.ctrlKey && e.shiftKey && ['I','J','C'].includes(e.key.toUpperCase())) ||
                (e.ctrlKey && ['U','S'].includes(e.key.toUpperCase())) ||
                e.key === 'PrintScreen'
            ) { e.preventDefault(); }
        };
        document.addEventListener('contextmenu', onCtx);
        document.addEventListener('keydown', onKey);
        return () => { document.removeEventListener('contextmenu', onCtx); document.removeEventListener('keydown', onKey); };
    }, []);

    // ── Anti-cheat: copy/paste ──────────────────────────────
    useEffect(() => {
        const block = (e: ClipboardEvent) => e.preventDefault();
        document.addEventListener('copy', block);
        document.addEventListener('cut', block);
        return () => { document.removeEventListener('copy', block); document.removeEventListener('cut', block); };
    }, []);

    // ── Timer ───────────────────────────────────────────────
    useEffect(() => {
        if (isSubmitting || isTimeUp) return;
        timerRef.current = setInterval(() => {
            setTimeLeft(prev => {
                if (prev <= 1) {
                    clearInterval(timerRef.current!);
                    setIsTimeUp(true);
                    if (!submitCalledRef.current) {
                        submitCalledRef.current = true;
                        toast.loading('Waktu habis! Menyimpan jawaban...', { duration: 3000 });
                        // Small delay so state settles before submit
                        setTimeout(() => doSubmitInternal(), 600);
                    }
                    return 0;
                }
                if (prev === 300) toast('⏰ Sisa 5 menit!', { duration: 5000, icon: '⏰' });
                if (prev === 60)  toast.error('⚠️ Sisa 1 menit!', { duration: 5000 });
                if (prev === 30)  toast.error('🚨 Sisa 30 detik!', { duration: 5000 });
                return prev - 1;
            });
        }, 1000);
        return () => { if (timerRef.current) clearInterval(timerRef.current); };
    }, [isSubmitting, isTimeUp]); // eslint-disable-line react-hooks/exhaustive-deps

    // ── Prevent navigation ──────────────────────────────────
    useEffect(() => {
        const onUnload = (e: BeforeUnloadEvent) => {
            if (!isSubmitting && !isTimeUp) { e.preventDefault(); e.returnValue = ''; }
        };
        const onPop = () => {
            if (!isSubmitting && !isTimeUp) {
                window.history.pushState(null, '', window.location.href);
                toast.error('Tidak bisa keluar dari quiz!', { duration: 3000 });
            }
        };
        window.addEventListener('beforeunload', onUnload);
        window.addEventListener('popstate', onPop);
        window.history.pushState(null, '', window.location.href);
        return () => { window.removeEventListener('beforeunload', onUnload); window.removeEventListener('popstate', onPop); };
    }, [isSubmitting, isTimeUp]);

    const formattedTime = useMemo(() => {
        const m = Math.floor(timeLeft / 60), s = timeLeft % 60;
        return `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
    }, [timeLeft]);

    const timeColor = useMemo(() => {
        if (timeLeft > 300) return 'text-emerald-400';
        if (timeLeft > 60)  return 'text-amber-400';
        return 'text-red-400 animate-pulse';
    }, [timeLeft]);

    const timeBg = useMemo(() => {
        if (timeLeft > 300) return 'bg-emerald-500/20 border-emerald-500/30';
        if (timeLeft > 60)  return 'bg-amber-500/20 border-amber-500/30';
        return 'bg-red-500/20 border-red-500/30';
    }, [timeLeft]);

    const handleAnswerChange = useCallback((questionId: number, answer: string) => {
        if (isTimeUp || isSubmitting) return;
        setAnswers(prev => ({ ...prev, [questionId]: answer }));
    }, [isTimeUp, isSubmitting]);

    // ── Core submit function (internal) ────────────────────
    // Uses router.post which triggers a redirect response from the server.
    // The server does: redirect()->route('quiz.result') after storing flash.
    // Inertia handles the redirect automatically → navigates to /result.
    const doSubmitInternal = useCallback(() => {
        setIsSubmitting(true);
        if (timerRef.current) clearInterval(timerRef.current);

        const timeTaken = (quizConfig.time_limit * 60) - Math.max(timeLeft, 0);

        router.post(
            `/module/${module.id}/quiz/submit`,
            { session_id: quizConfig.session_id, answers, time_taken: timeTaken },
            {
                // Let Inertia follow the redirect from the server
                onError: () => {
                    setIsSubmitting(false);
                    submitCalledRef.current = false;
                    toast.error('Gagal menyimpan quiz. Coba lagi.');
                },
            }
        );
    }, [isSubmitting, timeLeft, quizConfig, module.id, answers]); // eslint-disable-line react-hooks/exhaustive-deps

    const handleSubmit = useCallback(() => {
        if (isSubmitting || isTimeUp) return;
        if (!isAllAnswered) { setShowIncomplete(true); return; }
        setShowConfirmSubmit(true);
    }, [isSubmitting, isTimeUp, isAllAnswered]);

    const confirmSubmit = useCallback(() => {
        setShowConfirmSubmit(false);
        if (!submitCalledRef.current) {
            submitCalledRef.current = true;
            doSubmitInternal();
        }
    }, [doSubmitInternal]);

    const goToPrev = useCallback(() => setCurrentQuestion(p => Math.max(0, p - 1)), []);
    const goToNext = useCallback(() => setCurrentQuestion(p => Math.min(questions.length - 1, p + 1)), [questions.length]);

    const currentQ           = questions[currentQuestion];
    const isQuestionAnswered = answers[currentQ.id] !== undefined;

    return (
        <div className="min-h-screen bg-gray-950 select-none" style={{ userSelect: 'none' }}>
            <Toaster
                position="top-right"
                toastOptions={{
                    style:   { background: '#1f2937', color: '#f9fafb', borderRadius: '12px', border: '1px solid #374151' },
                    success: { style: { background: '#065f46', color: '#ecfdf5', border: '1px solid #10b981' } },
                    error:   { style: { background: '#7f1d1d', color: '#fef2f2', border: '1px solid #ef4444' } },
                }}
            />

            {/* Page-hidden overlay */}
            {!isPageVisible && (
                <div className="fixed inset-0 bg-gray-950 z-[100] flex items-center justify-center">
                    <div className="text-center text-white">
                        <Shield className="h-16 w-16 mx-auto mb-4 text-red-500" />
                        <p className="text-xl font-bold">Kembali ke quiz...</p>
                    </div>
                </div>
            )}

            {/* Time-up overlay */}
            {isTimeUp && (
                <div className="fixed inset-0 bg-gray-950/90 z-[90] flex items-center justify-center backdrop-blur-sm">
                    <div className="bg-gray-900 border border-red-500/50 rounded-2xl p-8 text-center max-w-sm mx-4">
                        <Clock className="h-16 w-16 text-red-500 mx-auto mb-4 animate-pulse" />
                        <h2 className="text-2xl font-bold text-white mb-2">Waktu Habis!</h2>
                        <p className="text-gray-400 mb-4">Jawaban Anda sedang disimpan otomatis...</p>
                        <div className="flex justify-center">
                            <div className="w-8 h-8 border-4 border-blue-500 border-t-transparent rounded-full animate-spin" />
                        </div>
                    </div>
                </div>
            )}

            <div className="max-w-6xl mx-auto p-3 sm:p-4 lg:p-6">
                {/* ── Sticky Header ── */}
                <div className="bg-gray-900 border border-gray-700/50 rounded-2xl p-3 sm:p-4 mb-4 sticky top-2 z-20 shadow-2xl shadow-black/50">
                    <div className="flex items-center justify-between gap-2">
                        {/* Left: module info */}
                        <div className="flex items-center gap-2 min-w-0">
                            <div className={`p-1.5 rounded-lg ${module.color} flex-shrink-0`}>
                                <Flag className="h-4 w-4 text-white" />
                            </div>
                            <div className="min-w-0">
                                <p className="text-sm font-semibold text-white truncate">Quiz {module.title}</p>
                                <p className="text-xs text-gray-500">
                                    Soal {currentQuestion + 1}/{questions.length} · Percobaan {quizConfig.attempt_number}/{quizConfig.max_attempts}
                                </p>
                            </div>
                        </div>

                        {/* Right: controls */}
                        <div className="flex items-center gap-1.5 sm:gap-3 flex-shrink-0">
                            {tabViolations > 0 && (
                                <div className="hidden sm:flex items-center gap-1 bg-red-500/20 border border-red-500/30 rounded-lg px-2 py-1">
                                    <Shield className="h-3 w-3 text-red-400" />
                                    <span className="text-xs text-red-400 font-bold">{tabViolations}x</span>
                                </div>
                            )}
                            <div className="hidden sm:block text-center">
                                <p className="text-xs text-gray-500">Dijawab</p>
                                <p className={`text-sm font-bold ${isAllAnswered ? 'text-emerald-400' : 'text-white'}`}>
                                    {answeredCount}/{questions.length}
                                </p>
                            </div>
                            <div className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl border ${timeBg}`}>
                                <Clock className={`h-3.5 w-3.5 ${timeColor}`} />
                                <span className={`text-sm font-bold tabular-nums ${timeColor}`}>{formattedTime}</span>
                            </div>
                            <button
                                onClick={handleSubmit}
                                disabled={isSubmitting || isTimeUp}
                                className={`flex items-center gap-1.5 py-1.5 px-3 rounded-xl font-semibold text-sm transition-all ${
                                    isAllAnswered && !isTimeUp
                                        ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-lg shadow-emerald-900/50'
                                        : 'bg-gray-700/50 text-gray-500 cursor-not-allowed'
                                }`}
                            >
                                <Send className="h-3.5 w-3.5" />
                                <span>{isSubmitting ? '...' : 'Submit'}</span>
                            </button>
                        </div>
                    </div>

                    {/* Progress bar */}
                    <div className="mt-2.5 w-full bg-gray-800 rounded-full h-1.5">
                        <div
                            className={`h-1.5 rounded-full transition-all duration-500 ${isAllAnswered ? 'bg-emerald-500' : 'bg-blue-500'}`}
                            style={{ width: `${progressPercentage}%` }}
                        />
                    </div>

                    {/* Mobile stats */}
                    <div className="sm:hidden flex justify-between mt-1.5 text-xs text-gray-500">
                        <span>{answeredCount}/{questions.length} dijawab</span>
                        {tabViolations > 0 && <span className="text-red-400">{tabViolations}x peringatan</span>}
                        {!isAllAnswered && <span className="text-amber-400">{questions.length - answeredCount} belum</span>}
                    </div>
                    {!isAllAnswered && (
                        <div className="hidden sm:flex mt-1.5 items-center gap-1.5 text-xs text-amber-400">
                            <AlertTriangle className="h-3 w-3" />
                            <span>{questions.length - answeredCount} soal belum dijawab</span>
                        </div>
                    )}
                </div>

                {/* ── Layout ── */}
                <div className="flex flex-col lg:grid lg:grid-cols-4 gap-4">
                    {/* Sidebar navigation */}
                    <div className="lg:col-span-1 order-2 lg:order-1">
                        <div className="bg-gray-900 border border-gray-700/50 rounded-2xl p-3 sm:p-4 lg:sticky lg:top-28">
                            <p className="text-xs font-semibold text-gray-400 mb-2.5">Navigasi Soal</p>
                            <div className="flex flex-wrap gap-1.5">
                                {questions.map((q, i) => (
                                    <button
                                        key={q.id}
                                        onClick={() => setCurrentQuestion(i)}
                                        className={`w-8 h-8 rounded-lg font-bold text-xs transition-all ${
                                            currentQuestion === i
                                                ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/50 scale-110'
                                                : answers[q.id]
                                                    ? 'bg-emerald-900/50 text-emerald-400 border border-emerald-700/50'
                                                    : 'bg-gray-800 text-gray-400 hover:bg-gray-700 border border-gray-700/50'
                                        }`}
                                    >
                                        {i + 1}
                                    </button>
                                ))}
                            </div>
                            <div className="hidden lg:flex flex-col gap-1.5 mt-3 text-xs">
                                {[
                                    { cls: 'bg-blue-600', label: 'Aktif' },
                                    { cls: 'bg-emerald-900/50 border border-emerald-700/50', label: 'Dijawab' },
                                    { cls: 'bg-gray-800 border border-gray-700/50', label: 'Belum' },
                                ].map(({ cls, label }) => (
                                    <div key={label} className="flex items-center gap-2">
                                        <div className={`w-3.5 h-3.5 rounded ${cls}`} />
                                        <span className="text-gray-500">{label}</span>
                                    </div>
                                ))}
                            </div>
                        </div>
                    </div>

                    {/* Question card */}
                    <div className="lg:col-span-3 order-1 lg:order-2">
                        <div className="bg-gray-900 border border-gray-700/50 rounded-2xl p-4 sm:p-6">
                            {/* Header */}
                            <div className="flex items-center justify-between mb-5">
                                <div className="flex items-center gap-2">
                                    <div className="w-8 h-8 rounded-xl bg-blue-600/20 border border-blue-500/30 flex items-center justify-center">
                                        <span className="text-sm font-bold text-blue-400">{currentQuestion + 1}</span>
                                    </div>
                                    <span className="text-xs text-gray-500">dari {questions.length} soal</span>
                                </div>
                                {isQuestionAnswered
                                    ? <div className="flex items-center gap-1.5 text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 rounded-lg px-2 py-1 text-xs">
                                        <CheckCircle className="h-3.5 w-3.5" /><span className="hidden sm:inline">Terjawab</span>
                                      </div>
                                    : <div className="flex items-center gap-1.5 text-gray-500 bg-gray-800/50 border border-gray-700/50 rounded-lg px-2 py-1 text-xs">
                                        <Circle className="h-3.5 w-3.5" /><span className="hidden sm:inline">Belum</span>
                                      </div>
                                }
                            </div>

                            {/* Question text */}
                            <p className="text-base sm:text-lg text-gray-100 leading-relaxed font-medium mb-6">
                                {currentQ.question}
                            </p>

                            {/* Options */}
                            <div className="space-y-2.5 mb-6">
                                {Object.entries(currentQ.options).map(([opt, txt]) => {
                                    const selected   = answers[currentQ.id] === opt;
                                    const disabled   = isTimeUp || isSubmitting;
                                    return (
                                        <label
                                            key={opt}
                                            className={`flex items-start gap-3 p-3 sm:p-4 rounded-xl border cursor-pointer transition-all duration-200 ${
                                                disabled ? 'cursor-not-allowed opacity-60' : ''
                                            } ${
                                                selected
                                                    ? 'border-blue-500 bg-blue-500/10'
                                                    : disabled
                                                        ? 'border-gray-700/50 bg-gray-800/30'
                                                        : 'border-gray-700/50 bg-gray-800/30 hover:border-gray-600 hover:bg-gray-800/60'
                                            }`}
                                        >
                                            <input
                                                type="radio"
                                                name={`q_${currentQ.id}`}
                                                value={opt}
                                                checked={selected}
                                                onChange={() => handleAnswerChange(currentQ.id, opt)}
                                                disabled={disabled}
                                                className="sr-only"
                                            />
                                            <div className={`w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0 font-bold text-sm transition-all ${
                                                selected ? 'bg-blue-600 text-white' : 'bg-gray-700/70 text-gray-400'
                                            }`}>
                                                {opt}
                                            </div>
                                            <span className={`flex-1 text-sm sm:text-base leading-relaxed mt-0.5 ${selected ? 'text-white' : 'text-gray-300'}`}>
                                                {txt}
                                            </span>
                                            {selected && <CheckCircle className="h-4 w-4 text-blue-400 flex-shrink-0 mt-0.5" />}
                                        </label>
                                    );
                                })}
                            </div>

                            {/* Navigation */}
                            <div className="flex items-center justify-between gap-3">
                                <button
                                    onClick={goToPrev}
                                    disabled={currentQuestion === 0}
                                    className="flex items-center gap-1.5 py-2 px-4 rounded-xl border border-gray-700/50 text-gray-400 hover:text-white hover:border-gray-600 hover:bg-gray-800 disabled:opacity-30 disabled:cursor-not-allowed transition-all text-sm font-medium"
                                >
                                    <ChevronLeft className="h-4 w-4" />
                                    <span>Sebelumnya</span>
                                </button>
                                <span className="text-xs text-gray-600 hidden sm:block">{currentQuestion + 1} / {questions.length}</span>
                                <button
                                    onClick={goToNext}
                                    disabled={currentQuestion === questions.length - 1}
                                    className="flex items-center gap-1.5 py-2 px-4 rounded-xl border border-gray-700/50 text-gray-400 hover:text-white hover:border-gray-600 hover:bg-gray-800 disabled:opacity-30 disabled:cursor-not-allowed transition-all text-sm font-medium"
                                >
                                    <span>Selanjutnya</span>
                                    <ChevronRight className="h-4 w-4" />
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* ── Modals ── */}
            {showCheatWarning && (
                <Modal onClose={() => setShowCheatWarning(false)}>
                    <div className="flex items-center gap-3 mb-4">
                        <div className="p-2 bg-red-500/20 rounded-xl"><Shield className="h-6 w-6 text-red-400" /></div>
                        <h3 className="text-lg font-bold text-white">Pelanggaran Terdeteksi!</h3>
                    </div>
                    <div className="bg-red-500/10 border border-red-500/30 rounded-xl p-4 mb-5">
                        <p className="text-red-300 text-sm">{cheatMsg}</p>
                        <p className="text-red-400/60 text-xs mt-1">Pelanggaran ke-{tabViolations} — aktivitas ini dicatat</p>
                    </div>
                    <button onClick={() => setShowCheatWarning(false)} className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-semibold">
                        Kembali ke Quiz
                    </button>
                </Modal>
            )}

            {showIncomplete && (
                <Modal onClose={() => setShowIncomplete(false)}>
                    <div className="flex items-center gap-3 mb-4">
                        <div className="p-2 bg-amber-500/20 rounded-xl"><AlertTriangle className="h-6 w-6 text-amber-400" /></div>
                        <h3 className="text-lg font-bold text-white">Soal Belum Lengkap</h3>
                    </div>
                    <div className="bg-amber-500/10 border border-amber-500/30 rounded-xl p-4 mb-5">
                        <p className="text-amber-300 text-sm mb-2">Soal yang belum dijawab:</p>
                        <div className="flex flex-wrap gap-1.5">
                            {unansweredNums.map(n => (
                                <span key={n} className="bg-amber-500/20 text-amber-300 text-xs font-bold px-2 py-0.5 rounded border border-amber-500/30">{n}</span>
                            ))}
                        </div>
                        <p className="text-amber-400/60 text-xs mt-2">{questions.length - answeredCount} soal belum terjawab</p>
                    </div>
                    <button onClick={() => setShowIncomplete(false)} className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl font-semibold">
                        Lanjutkan Mengerjakan
                    </button>
                </Modal>
            )}

            {showConfirmSubmit && (
                <Modal onClose={() => setShowConfirmSubmit(false)}>
                    <div className="flex items-center gap-3 mb-4">
                        <div className="p-2 bg-emerald-500/20 rounded-xl"><CheckCircle className="h-6 w-6 text-emerald-400" /></div>
                        <h3 className="text-lg font-bold text-white">Konfirmasi Submit Quiz</h3>
                    </div>
                    <div className="space-y-2 mb-5 text-sm">
                        <div className="bg-emerald-500/10 border border-emerald-500/20 rounded-xl p-3 flex gap-2">
                            <CheckCircle className="h-4 w-4 text-emerald-400 flex-shrink-0" />
                            <span className="text-emerald-300">Semua soal terjawab ({answeredCount}/{questions.length})</span>
                        </div>
                        <div className="bg-gray-800/50 border border-gray-700/50 rounded-xl p-3 flex gap-2">
                            <Clock className="h-4 w-4 text-blue-400 flex-shrink-0" />
                            <span className="text-gray-300">Sisa waktu: <strong className="text-white">{formattedTime}</strong></span>
                        </div>
                        <div className="bg-red-500/10 border border-red-500/20 rounded-xl p-3 flex gap-2">
                            <AlertTriangle className="h-4 w-4 text-red-400 flex-shrink-0" />
                            <span className="text-red-300">Jawaban tidak dapat diubah setelah submit</span>
                        </div>
                    </div>
                    <div className="flex gap-3">
                        <button onClick={() => setShowConfirmSubmit(false)} className="flex-1 py-2.5 border border-gray-600 text-gray-400 hover:text-white rounded-xl text-sm font-medium">
                            Batal
                        </button>
                        <button onClick={confirmSubmit} className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-semibold text-sm">
                            Ya, Submit Quiz
                        </button>
                    </div>
                </Modal>
            )}
        </div>
    );
}

function Modal({ children, onClose }: { children: React.ReactNode; onClose: () => void }) {
    return (
        <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4 backdrop-blur-sm">
            <div className="bg-gray-900 border border-gray-700/50 rounded-2xl p-5 sm:p-6 max-w-md w-full shadow-2xl">
                {children}
            </div>
        </div>
    );
}
