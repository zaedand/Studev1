import React, { useState, useEffect, useMemo } from 'react';
import AppLayout from '@/layouts/app-layout';
import { type BreadcrumbItem } from '@/types';
import { router, useForm } from '@inertiajs/react';
import { useCustomToast } from '@/hooks/use-toast';
import {
    Upload, Plus, Edit3, Trash2, Eye, Search, Download,
    Calendar, FileText, Star, BarChart3, X, Save, AlertTriangle,
    ArrowLeft, Users, CheckCircle, Clock, Award, Filter
} from 'lucide-react';

interface Assignment {
    id: number;
    title: string;
    moduleId: number;
    moduleName: string;
    description: string;
    deadline: string;
    classDeadlines: ClassDeadline[];
    maxScore: number;
    submissions: number;
    totalStudents: number;
    averageScore: number;
    status: 'active' | 'draft';
    createdAt: string;
    pointRewardEarly?: number;
    pointRewardOntime?: number;
    pointRewardLate?: number;
}

interface Module {
    id: number;
    title: string;
    order: number;
}

interface Submission {
    id: number;
    assignmentId: number;
    assignmentTitle: string;
    studentId: number;
    studentName: string;
    nim: string;
    fileName: string;
    fileSize: string;
    submittedAt: string;
    status: 'graded' | 'submitted';
    score: number | null;
    feedback: string;
    isLate: boolean;
    daysLate: number;
    daysEarly: number;
}

interface AssignmentFormData {
    title: string;
    module_id: string;
    description: string;
    instructions: string;
    deadline: string;
    class_deadlines: Array<{
        class_id: string;
        deadline: string;
    }>;
    max_score: number;
    point_reward_early: number;
    point_reward_ontime: number;
    point_reward_late: number;
    is_active: boolean;
}

interface ClassDeadline {
    classId: number;
    className: string;
    deadline: string;
}

interface Class {
    id: number;
    name: string;
}

const breadcrumbs: BreadcrumbItem[] = [
    { title: 'Dashboard', href: '/instructor/dashboard' },
    { title: 'Praktikum Management', href: '/instructor/praktikum' },
];

export default function InstructorPraktikumManagement({
    assignments = [],
    modules = [],
    classes = []
}: {
    assignments?: Assignment[],
    modules?: Module[],
    classes?: Class[]
}) {
    const toast = useCustomToast();

    const [activeTab, setActiveTab] = useState('assignments');
    const [showModal, setShowModal] = useState(false);
    const [modalType, setModalType] = useState('');
    const [selectedItem, setSelectedItem] = useState<any>(null);
    const [searchTerm, setSearchTerm] = useState('');
    const [submissions, setSubmissions] = useState<Submission[]>([]);
    const [analytics, setAnalytics] = useState<any>(null);
    const [selectedAssignment, setSelectedAssignment] = useState<Assignment | null>(null);
    const [selectedSubmission, setSelectedSubmission] = useState<Submission | null>(null);
    const [showPdfPreview, setShowPdfPreview] = useState(false);
    const [pdfUrl, setPdfUrl] = useState('');
    const [selectedModuleFilter, setSelectedModuleFilter] = useState<number | 'all'>('all');
    const [loading, setLoading] = useState(false);

    const assignmentForm = useForm<AssignmentFormData>({
        title: '',
        module_id: '',
        description: '',
        instructions: '',
        deadline: '',
        class_deadlines: (classes || []).map(cls => ({
            class_id: cls.id.toString(),
            deadline: ''
        })),
        max_score: 100,
        point_reward_early: 10,
        point_reward_ontime: 5,
        point_reward_late: 2,
        is_active: false,
    });

    const gradeForm = useForm({
        score: '',
        feedback: '',
    });

    // Fetch submissions for selected assignment
    const fetchSubmissions = async (assignmentId: number) => {
        setLoading(true);
        try {
            const response = await fetch(`/instructor/praktikum/submissions?assignment_id=${assignmentId}`);
            const data = await response.json();
            setSubmissions(data);
        } catch (err) {
            console.error('Error fetching submissions:', err);
            toast.error('Gagal memuat data pengumpulan');
        } finally {
            setLoading(false);
        }
    };

    // Fetch analytics
    useEffect(() => {
        if (activeTab === 'analytics') {
            setLoading(true);
            fetch('/instructor/praktikum/analytics')
                .then(res => res.json())
                .then(data => {
                    setAnalytics(data);
                    setLoading(false);
                })
                .catch(err => {
                    console.error('Error fetching analytics:', err);
                    toast.error('Gagal memuat data analitik');
                    setLoading(false);
                });
        }
    }, [activeTab]);

    // Calculate total students safely
    const getTotalStudents = () => {
        if (!assignments || assignments.length === 0) return 0;
        return assignments[0]?.totalStudents || 0;
    };

    // OPTIMIZED: Filtered assignments with stable search
    const filteredAssignments = useMemo(() => {
        if (!assignments || assignments.length === 0) return [];

        let filtered = [...assignments];

        // Filter by search term
        if (searchTerm.trim()) {
            const search = searchTerm.toLowerCase().trim();
            filtered = filtered.filter(assignment =>
                assignment.title?.toLowerCase().includes(search) ||
                assignment.moduleName?.toLowerCase().includes(search) ||
                assignment.description?.toLowerCase().includes(search)
            );
        }

        // Filter by module
        if (selectedModuleFilter !== 'all') {
            filtered = filtered.filter(a => a.moduleId === selectedModuleFilter);
        }

        return filtered;
    }, [assignments, searchTerm, selectedModuleFilter]);

    // OPTIMIZED: Group assignments by module with stable filtering
    const assignmentsByModule = useMemo(() => {
        if (!modules || modules.length === 0) return [];

        const totalStudents = getTotalStudents();

        return modules
            .map(module => {
                const moduleAssignments = filteredAssignments.filter(
                    a => a.moduleId === module.id
                );

                return {
                    module,
                    assignments: moduleAssignments,
                    totalSubmissions: moduleAssignments.reduce((sum, a) => sum + (a.submissions || 0), 0),
                    totalPossible: moduleAssignments.length * totalStudents,
                };
            })
            .filter(m => m.assignments.length > 0);
    }, [modules, filteredAssignments]);

    const handleCreateAssignment = () => {
        toast.withLoading(
            new Promise((resolve, reject) => {
                assignmentForm.post('/instructor/praktikum', {
                    onSuccess: () => {
                        setShowModal(false);
                        assignmentForm.reset();
                        resolve(true);
                    },
                    onError: (errors) => {
                        console.error(errors);
                        reject(errors);
                    }
                });
            }),
            {
                loading: 'Membuat praktikum...',
                success: 'Praktikum berhasil dibuat! 🎉',
                error: 'Gagal membuat praktikum. Periksa form Anda.',
            }
        );
    };

    const handleUpdateAssignment = () => {
        toast.withLoading(
            new Promise((resolve, reject) => {
                assignmentForm.put(`/instructor/praktikum/${selectedItem.id}`, {
                    onSuccess: () => {
                        setShowModal(false);
                        assignmentForm.reset();
                        resolve(true);
                    },
                    onError: (errors) => {
                        console.error(errors);
                        reject(errors);
                    }
                });
            }),
            {
                loading: 'Memperbarui praktikum...',
                success: 'Praktikum berhasil diperbarui! ✅',
                error: 'Gagal memperbarui praktikum.',
            }
        );
    };

    const handleDeleteAssignment = (id: number) => {
        if (confirm('Apakah Anda yakin ingin menghapus praktikum ini?')) {
            toast.withLoading(
                new Promise((resolve, reject) => {
                    router.delete(`/instructor/praktikum/${id}`, {
                        onSuccess: () => resolve(true),
                        onError: () => reject(),
                    });
                }),
                {
                    loading: 'Menghapus praktikum...',
                    success: 'Praktikum berhasil dihapus! 🗑️',
                    error: 'Gagal menghapus praktikum.',
                }
            );
        }
    };

    const handleGradeSubmission = () => {
        if (!selectedSubmission) return;

        const score = parseInt(gradeForm.data.score);
        const studentName = selectedSubmission.studentName;

        toast.withLoading(
            new Promise((resolve, reject) => {
                gradeForm.post(`/instructor/praktikum/submissions/${selectedSubmission.id}/grade`, {
                    onSuccess: () => {
                        setShowModal(false);
                        gradeForm.reset();
                        if (selectedAssignment) {
                            fetchSubmissions(selectedAssignment.id);
                        }
                        resolve(true);
                    },
                    onError: (errors) => {
                        console.error(errors);
                        reject(errors);
                    }
                });
            }),
            {
                loading: 'Menyimpan nilai...',
                success: `Nilai ${studentName} berhasil disimpan: ${score}/100 ⭐`,
                error: 'Gagal menyimpan nilai.',
            }
        );
    };

    const openCreateModal = () => {
        assignmentForm.reset();
        assignmentForm.setData('class_deadlines', (classes || []).map(cls => ({
            class_id: cls.id.toString(),
            deadline: ''
        })));
        setModalType('create');
        setShowModal(true);
    };

    const openEditModal = (assignment: Assignment) => {
        setSelectedItem(assignment);
        assignmentForm.setData({
            title: assignment.title,
            module_id: assignment.moduleId.toString(),
            description: assignment.description,
            instructions: '',
            deadline: assignment.deadline || '',
            class_deadlines: (classes || []).map(cls => {
                const existing = assignment.classDeadlines?.find(cd => cd.classId === cls.id);
                return {
                    class_id: cls.id.toString(),
                    deadline: existing ? existing.deadline : ''
                };
            }),
            max_score: assignment.maxScore,
            point_reward_early: assignment.pointRewardEarly || 10,
            point_reward_ontime: assignment.pointRewardOntime || 5,
            point_reward_late: assignment.pointRewardLate || 2,
            is_active: assignment.status === 'active',
        });
        setModalType('edit');
        setShowModal(true);
    };

    const openAssignmentDetail = (assignment: Assignment) => {
        setSelectedAssignment(assignment);
        fetchSubmissions(assignment.id);
    };

    const openGradeModal = (submission: Submission) => {
        setSelectedSubmission(submission);
        gradeForm.setData({
            score: submission.score?.toString() || '',
            feedback: submission.feedback || '',
        });
        setModalType('grade');
        setShowModal(true);
    };

    const openPdfPreview = (submission: Submission) => {
        setSelectedSubmission(submission);
        setPdfUrl(`/instructor/praktikum/submissions/${submission.id}/preview`);
        setShowPdfPreview(true);
    };

    const getStatusColor = (status: string) => {
        const colors = {
            active: 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300',
            draft: 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-300',
            closed: 'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300',
        };
        return colors[status as keyof typeof colors] || 'bg-gray-100 dark:bg-gray-900/30 text-gray-700 dark:text-gray-300';
    };

    const formatDeadline = (deadline: string) => {
        const date = new Date(deadline);
        const now = new Date();
        const diff = date.getTime() - now.getTime();
        const days = Math.ceil(diff / (1000 * 60 * 60 * 24));

        if (days > 0) return `${days} hari lagi`;
        if (days === 0) return 'Hari ini';
        return `Terlambat ${Math.abs(days)} hari`;
    };

    // Show loading or empty state if no data
    if (!assignments || !modules || !classes) {
        return (
            <AppLayout breadcrumbs={breadcrumbs}>
                <div className="flex h-full flex-1 items-center justify-center p-4 md:p-6">
                    <div className="text-center">
                        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
                        <p className="text-gray-500">Memuat data...</p>
                    </div>
                </div>
            </AppLayout>
        );
    }

    return (
        <AppLayout breadcrumbs={breadcrumbs}>
            <div className="flex h-full flex-1 flex-col gap-6 p-4 md:p-6">
                {/* Header */}
                <div className="mb-4 md:mb-8">
                    <h1 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white mb-2">
                        Praktikum Management
                    </h1>
                    <p className="text-sm md:text-base text-gray-600 dark:text-gray-400">
                        Kelola tugas praktikum dan monitor pengumpulan mahasiswa
                    </p>
                </div>

                {/* Navigation Tabs */}
                <div className="flex border-b border-gray-200 dark:border-gray-700 mb-6 overflow-x-auto">
                    {[
                        { id: 'assignments', label: 'Daftar Praktikum', icon: Upload },
                        { id: 'analytics', label: 'Analisis', icon: BarChart3 }
                    ].map((tab) => {
                        const Icon = tab.icon;
                        return (
                            <button
                                key={tab.id}
                                onClick={() => {
                                    setActiveTab(tab.id);
                                    setSelectedAssignment(null);
                                }}
                                className={`flex items-center gap-2 px-4 md:px-6 py-3 font-medium transition-colors whitespace-nowrap ${
                                    activeTab === tab.id
                                        ? 'text-blue-600 dark:text-blue-400 border-b-2 border-blue-600'
                                        : 'text-gray-500 dark:text-gray-400 hover:text-gray-700'
                                }`}
                            >
                                <Icon className="h-4 w-4 md:h-5 md:w-5" />
                                <span className="hidden sm:inline">{tab.label}</span>
                            </button>
                        );
                    })}
                </div>

                {/* Assignments Tab */}
                {activeTab === 'assignments' && !selectedAssignment && (
                    <div className="space-y-6">
                        {/* Search and Filter */}
                        <div className="flex flex-col gap-3 sm:gap-4">
                            {/* Search */}
                            <div className="relative flex-1">
                                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-4 w-4" />
                                <input
                                    type="text"
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    placeholder="Cari praktikum atau modul..."
                                    className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                                />
                            </div>

                            {/* Filter and Button Row */}
                            <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center">
                                {/* Filter Modul */}
                                <div className="relative flex-1 sm:max-w-xs">
                                    <Filter className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 h-4 w-4" />
                                    <select
                                        value={selectedModuleFilter}
                                        onChange={(e) =>
                                            setSelectedModuleFilter(
                                                e.target.value === 'all' ? 'all' : Number(e.target.value)
                                            )
                                        }
                                        className="w-full pl-10 pr-4 py-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500 appearance-none"
                                    >
                                        <option value="all">Semua Modul</option>
                                        {modules.map((module) => (
                                            <option key={module.id} value={module.id}>
                                                {module.title}
                                            </option>
                                        ))}
                                    </select>
                                </div>

                                {/* Create Button */}
                                <button
                                    onClick={openCreateModal}
                                    className="flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors whitespace-nowrap"
                                >
                                    <Plus className="h-4 w-4" />
                                    <span className="hidden sm:inline">Buat Praktikum Baru</span>
                                    <span className="sm:hidden">Buat Praktikum</span>
                                </button>
                            </div>
                        </div>

                        {/* Show filtered results count */}
                        {(searchTerm || selectedModuleFilter !== 'all') && (
                            <div className="flex items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                                <span>
                                    Menampilkan {filteredAssignments.length} dari {assignments.length} praktikum
                                </span>
                                {(searchTerm || selectedModuleFilter !== 'all') && (
                                    <button
                                        onClick={() => {
                                            setSearchTerm('');
                                            setSelectedModuleFilter('all');
                                        }}
                                        className="text-blue-600 hover:text-blue-700 dark:text-blue-400 dark:hover:text-blue-300 underline"
                                    >
                                        Reset Filter
                                    </button>
                                )}
                            </div>
                        )}

                        {/* Show message if no assignments or no results */}
                        {assignmentsByModule.length === 0 ? (
                            <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-8 md:p-12 text-center">
                                <Upload className="h-12 w-12 md:h-16 md:w-16 mx-auto mb-4 text-gray-400" />
                                <h3 className="text-lg md:text-xl font-semibold text-gray-900 dark:text-white mb-2">
                                    {searchTerm || selectedModuleFilter !== 'all'
                                        ? 'Praktikum Tidak Ditemukan'
                                        : 'Belum Ada Praktikum'
                                    }
                                </h3>
                                <p className="text-sm md:text-base text-gray-500 mb-6">
                                    {searchTerm || selectedModuleFilter !== 'all'
                                        ? 'Coba kata kunci lain atau ubah filter'
                                        : 'Mulai dengan membuat praktikum baru untuk mahasiswa Anda'
                                    }
                                </p>
                                {!searchTerm && selectedModuleFilter === 'all' && (
                                    <button
                                        onClick={openCreateModal}
                                        className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 md:px-6 py-2 md:py-3 rounded-lg transition-colors"
                                    >
                                        <Plus className="h-4 w-4 md:h-5 md:w-5" />
                                        Buat Praktikum Pertama
                                    </button>
                                )}
                            </div>
                        ) : (
                            /* Group by Module */
                            assignmentsByModule.map(({ module, assignments: moduleAssignments }) => (
                                <div key={module.id} className="space-y-4">
                                    <div className="flex items-center justify-between">
                                        <h2 className="text-lg md:text-xl font-semibold text-gray-900 dark:text-white">
                                            {module.title}
                                        </h2>
                                        <span className="text-xs md:text-sm text-gray-500">
                                            {moduleAssignments.length} praktikum
                                        </span>
                                    </div>

                                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
                                        {moduleAssignments.map((assignment) => (
                                            <div
                                                key={assignment.id}
                                                className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-4 md:p-6 hover:shadow-lg transition-all duration-200 cursor-pointer"
                                                onClick={() => openAssignmentDetail(assignment)}
                                            >
                                                <div className="flex items-start justify-between mb-4">
                                                    <div className="flex-1 min-w-0">
                                                        <div className="flex items-center gap-2 mb-2 flex-wrap">
                                                            <h3 className="text-base md:text-lg font-semibold text-gray-900 dark:text-white truncate">
                                                                {assignment.title}
                                                            </h3>
                                                            <span className={`px-2 py-1 text-xs rounded-full flex-shrink-0 ${getStatusColor(assignment.status)}`}>
                                                                {assignment.status === 'active' ? 'Aktif' : 'Draft'}
                                                            </span>
                                                        </div>
                                                        <p className="text-xs md:text-sm text-gray-700 dark:text-gray-300 line-clamp-2 mb-3">
                                                            {assignment.description}
                                                        </p>
                                                    </div>

                                                    <div
                                                        className="flex items-center gap-1 ml-2"
                                                        onClick={(e) => e.stopPropagation()}
                                                    >
                                                        <button
                                                            onClick={() => openEditModal(assignment)}
                                                            className="p-2 text-green-600 hover:bg-green-50 dark:hover:bg-green-900/20 rounded-lg transition-colors"
                                                            title="Edit"
                                                        >
                                                            <Edit3 className="h-4 w-4" />
                                                        </button>
                                                        <button
                                                            onClick={() => handleDeleteAssignment(assignment.id)}
                                                            className="p-2 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                                                            title="Hapus"
                                                        >
                                                            <Trash2 className="h-4 w-4" />
                                                        </button>
                                                    </div>
                                                </div>

                                                <div className="grid grid-cols-2 gap-3 md:gap-4 mb-4">
                                                    <div className="text-center p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                                                        <Users className="h-5 w-5 mx-auto mb-1 text-blue-600" />
                                                        <p className="text-xl md:text-2xl font-bold text-blue-600">{assignment.submissions || 0}</p>
                                                        <p className="text-xs text-gray-600 dark:text-gray-400">Dikumpulkan</p>
                                                    </div>
                                                    <div className="text-center p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                                                        <Award className="h-5 w-5 mx-auto mb-1 text-green-600" />
                                                        <p className="text-xl md:text-2xl font-bold text-green-600">{assignment.averageScore || 0}</p>
                                                        <p className="text-xs text-gray-600 dark:text-gray-400">Rata-rata</p>
                                                    </div>
                                                </div>

                                                {assignment.deadline && (
                                                    <div className="p-3 rounded-lg border bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800 mb-3">
                                                        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-1">
                                                            <div className="flex items-center gap-2">
                                                                <Calendar className="h-4 w-4 text-blue-500 flex-shrink-0" />
                                                                <span className="text-xs md:text-sm font-medium text-blue-700 dark:text-blue-300">
                                                                    {formatDeadline(assignment.deadline)}
                                                                </span>
                                                            </div>
                                                            <span className="text-xs text-gray-500 ml-6 sm:ml-0">
                                                                {new Date(assignment.deadline).toLocaleDateString('id-ID', {
                                                                    day: 'numeric',
                                                                    month: 'short',
                                                                    year: 'numeric'
                                                                })}
                                                            </span>
                                                        </div>
                                                    </div>
                                                )}

                                                <div>
                                                    <div className="flex justify-between text-xs text-gray-500 mb-1">
                                                        <span>Progress</span>
                                                        <span>
                                                            {Math.round(((assignment.submissions || 0) / (assignment.totalStudents || 1)) * 100)}%
                                                        </span>
                                                    </div>
                                                    <div className="w-full bg-gray-200 dark:bg-gray-700 rounded-full h-2">
                                                        <div
                                                            className="bg-blue-500 h-2 rounded-full transition-all"
                                                            style={{
                                                                width: `${Math.min(100, ((assignment.submissions || 0) / (assignment.totalStudents || 1)) * 100)}%`
                                                            }}
                                                        />
                                                    </div>
                                                </div>
                                            </div>
                                        ))}
                                    </div>
                                </div>
                            ))
                        )}
                    </div>
                )}

                {/* Assignment Detail - Submissions List */}
                {activeTab === 'assignments' && selectedAssignment && (
                    <div className="space-y-6">
                        <div className="flex items-center gap-4 mb-6">
                            <button
                                onClick={() => setSelectedAssignment(null)}
                                className="flex items-center gap-2 text-gray-600 hover:text-gray-800 dark:text-gray-400 dark:hover:text-gray-200 transition-colors"
                            >
                                <ArrowLeft className="h-5 w-5" />
                                <span className="hidden sm:inline">Kembali</span>
                            </button>
                            <div className="flex-1 min-w-0">
                                <h2 className="text-xl md:text-2xl font-bold text-gray-900 dark:text-white truncate">
                                    {selectedAssignment.title}
                                </h2>
                                <p className="text-xs md:text-sm text-gray-500">{selectedAssignment.moduleName}</p>
                            </div>
                        </div>

                        {/* Stats Cards */}
                        <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
                            <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
                                <Users className="h-5 w-5 md:h-6 md:w-6 text-blue-600 mb-2" />
                                <p className="text-xl md:text-2xl font-bold text-blue-600">{submissions.length}</p>
                                <p className="text-xs md:text-sm text-gray-600 dark:text-gray-400">Total Pengumpulan</p>
                            </div>
                            <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg border border-green-200 dark:border-green-800">
                                <CheckCircle className="h-5 w-5 md:h-6 md:w-6 text-green-600 mb-2" />
                                <p className="text-xl md:text-2xl font-bold text-green-600">
                                    {submissions.filter(s => s.score !== null).length}
                                </p>
                                <p className="text-xs md:text-sm text-gray-600 dark:text-gray-400">Sudah Dinilai</p>
                            </div>
                            <div className="bg-yellow-50 dark:bg-yellow-900/20 p-4 rounded-lg border border-yellow-200 dark:border-yellow-800">
                                <Clock className="h-5 w-5 md:h-6 md:w-6 text-yellow-600 mb-2" />
                                <p className="text-xl md:text-2xl font-bold text-yellow-600">
                                    {submissions.filter(s => s.score === null).length}
                                </p>
                                <p className="text-xs md:text-sm text-gray-600 dark:text-gray-400">Belum Dinilai</p>
                            </div>
                            <div className="bg-purple-50 dark:bg-purple-900/20 p-4 rounded-lg border border-purple-200 dark:border-purple-800">
                                <Award className="h-5 w-5 md:h-6 md:w-6 text-purple-600 mb-2" />
                                <p className="text-xl md:text-2xl font-bold text-purple-600">
                                    {submissions.filter(s => s.score !== null).length > 0
                                        ? Math.round(submissions.filter(s => s.score !== null).reduce((sum, s) => sum + (s.score || 0), 0) / submissions.filter(s => s.score !== null).length)
                                        : 0}
                                </p>
                                <p className="text-xs md:text-sm text-gray-600 dark:text-gray-400">Rata-rata Nilai</p>
                            </div>
                        </div>

                        {/* Submissions List */}
                        <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 overflow-hidden">
                            <div className="p-4 border-b border-gray-200 dark:border-gray-700">
                                <h3 className="font-semibold text-gray-900 dark:text-white">
                                    Daftar Pengumpulan Mahasiswa
                                </h3>
                            </div>
                            <div className="divide-y divide-gray-200 dark:divide-gray-700">
                                {loading ? (
                                    <div className="p-8 text-center">
                                        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto mb-2"></div>
                                        <p className="text-sm text-gray-500">Memuat data...</p>
                                    </div>
                                ) : submissions.length === 0 ? (
                                    <div className="p-8 text-center text-gray-500">
                                        <FileText className="h-12 w-12 mx-auto mb-2 text-gray-400" />
                                        <p>Belum ada mahasiswa yang mengumpulkan tugas</p>
                                    </div>
                                ) : (
                                    submissions.map((submission) => (
                                        <div key={submission.id} className="p-4 md:p-6 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                                            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                                                <div className="flex-1 min-w-0">
                                                    <div className="flex items-center gap-2 mb-2 flex-wrap">
                                                        <h4 className="font-semibold text-gray-900 dark:text-white">
                                                            {submission.studentName}
                                                        </h4>
                                                        <span className="text-xs md:text-sm text-gray-500">
                                                            {submission.nim}
                                                        </span>
                                                        {submission.score !== null && (
                                                            <span className={`px-2 py-1 text-xs rounded-full ${
                                                                submission.score >= 80
                                                                    ? 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300'
                                                                    : submission.score >= 60
                                                                    ? 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-300'
                                                                    : 'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300'
                                                            }`}>
                                                                Nilai: {submission.score}
                                                            </span>
                                                        )}
                                                        {submission.isLate && (
                                                            <span className="px-2 py-1 text-xs rounded-full bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300">
                                                                Terlambat {Math.abs(Math.floor(submission.daysLate))} hari
                                                            </span>
                                                        )}
                                                    </div>
                                                    <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4 text-xs md:text-sm text-gray-600 dark:text-gray-400">
                                                        <div className="flex items-center gap-1">
                                                            <FileText className="h-4 w-4 flex-shrink-0" />
                                                            <span className="truncate">{submission.fileName}</span>
                                                        </div>
                                                        <span className="hidden sm:inline">•</span>
                                                        <span>{submission.fileSize}</span>
                                                        <span className="hidden sm:inline">•</span>
                                                        <span>{new Date(submission.submittedAt).toLocaleString('id-ID', {
                                                            day: 'numeric',
                                                            month: 'short',
                                                            year: 'numeric',
                                                            hour: '2-digit',
                                                            minute: '2-digit'
                                                        })}</span>
                                                    </div>
                                                </div>
                                                <div className="flex items-center gap-2">
                                                    <button
                                                        onClick={() => openPdfPreview(submission)}
                                                        className="flex-1 sm:flex-initial flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-3 md:px-4 py-2 rounded-lg transition-colors text-sm"
                                                    >
                                                        <Eye className="h-4 w-4" />
                                                        <span className="hidden sm:inline">Lihat</span>
                                                    </button>
                                                    <button
                                                        onClick={() => openGradeModal(submission)}
                                                        className="flex-1 sm:flex-initial flex items-center justify-center gap-2 bg-green-600 hover:bg-green-700 text-white px-3 md:px-4 py-2 rounded-lg transition-colors text-sm"
                                                    >
                                                        <Star className="h-4 w-4" />
                                                        <span className="hidden sm:inline">Nilai</span>
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    ))
                                )}
                            </div>
                        </div>
                    </div>
                )}

                {/* Analytics Tab */}
                {activeTab === 'analytics' && (
                    <div className="space-y-6">
                        <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                            Analisis Praktikum
                        </h2>

                        {loading ? (
                            <div className="flex justify-center py-8">
                                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                            </div>
                        ) : analytics ? (
                            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
                                <div className="bg-white dark:bg-gray-800 p-4 md:p-6 rounded-xl border border-gray-200 dark:border-gray-700">
                                    <Award className="h-6 w-6 md:h-8 md:w-8 text-orange-600 mb-3" />
                                    <h3 className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-2">Rata-rata Nilai</h3>
                                    <p className="text-2xl md:text-3xl font-bold text-orange-600">{analytics.averageScore || 0}</p>
                                </div>
                                <div className="bg-white dark:bg-gray-800 p-4 md:p-6 rounded-xl border border-gray-200 dark:border-gray-700">
                                    <AlertTriangle className="h-6 w-6 md:h-8 md:w-8 text-red-600 mb-3" />
                                    <h3 className="text-sm font-medium text-gray-600 dark:text-gray-400 mb-2">Terlambat</h3>
                                    <p className="text-2xl md:text-3xl font-bold text-red-600">{analytics.lateSubmissions || 0}</p>
                                </div>
                            </div>
                        ) : (
                            <div className="text-center py-8 text-gray-500">
                                <BarChart3 className="h-16 w-16 mx-auto mb-4 text-gray-400" />
                                <p>Belum ada data analitik</p>
                            </div>
                        )}
                    </div>
                )}

                {/* PDF Preview Modal */}
                {showPdfPreview && selectedSubmission && (
                    <div className="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center p-4 z-50">
                        <div className="bg-white dark:bg-gray-800 rounded-xl w-full max-w-6xl h-[90vh] flex flex-col">
                            <div className="p-4 border-b border-gray-200 dark:border-gray-700 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                                <div className="min-w-0">
                                    <h3 className="text-base md:text-lg font-semibold text-gray-900 dark:text-white truncate">
                                        {selectedSubmission.studentName} - {selectedSubmission.assignmentTitle}
                                    </h3>
                                    <p className="text-xs md:text-sm text-gray-500 truncate">
                                        File: {selectedSubmission.fileName}
                                    </p>
                                </div>
                                <div className="flex items-center gap-2 flex-shrink-0">
                                    <a
                                        href={`/instructor/praktikum/submissions/${selectedSubmission.id}/download`}
                                        className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-3 md:px-4 py-2 rounded-lg text-sm transition-colors"
                                    >
                                        <Download className="h-4 w-4" />
                                        <span className="hidden sm:inline">Download</span>
                                    </a>
                                    <button
                                        onClick={() => {
                                            setShowPdfPreview(false);
                                            openGradeModal(selectedSubmission);
                                        }}
                                        className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-3 md:px-4 py-2 rounded-lg text-sm transition-colors"
                                    >
                                        <Star className="h-4 w-4" />
                                        <span className="hidden sm:inline">Beri Nilai</span>
                                    </button>
                                    <button
                                        onClick={() => setShowPdfPreview(false)}
                                        className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300 p-2"
                                    >
                                        <X className="h-6 w-6" />
                                    </button>
                                </div>
                            </div>
                            <div className="flex-1 p-4 overflow-hidden">
                                <iframe
                                    src={pdfUrl}
                                    className="w-full h-full rounded-lg border border-gray-300 dark:border-gray-600"
                                    title="PDF Preview"
                                />
                            </div>
                        </div>
                    </div>
                )}

                {/* Create/Edit Assignment Modal */}
                {showModal && (modalType === 'create' || modalType === 'edit') && (
                    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50 overflow-y-auto">
                        <div className="bg-white dark:bg-gray-800 rounded-xl max-w-4xl w-full my-8">
                            <div className="sticky top-0 p-4 md:p-6 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 rounded-t-xl z-10">
                                <div className="flex items-center justify-between">
                                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                                        {modalType === 'create' ? 'Buat Praktikum Baru' : 'Edit Praktikum'}
                                    </h3>
                                    <button
                                        onClick={() => setShowModal(false)}
                                        className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
                                    >
                                        <X className="h-6 w-6" />
                                    </button>
                                </div>
                            </div>

                            <div className="p-4 md:p-6 max-h-[calc(90vh-180px)] overflow-y-auto">
                                <div className="space-y-6">
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                                Judul Praktikum <span className="text-red-500">*</span>
                                            </label>
                                            <input
                                                type="text"
                                                value={assignmentForm.data.title}
                                                onChange={e => assignmentForm.setData('title', e.target.value)}
                                                className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                                                placeholder="Contoh: Praktikum 1 - Program Pertama"
                                            />
                                            {assignmentForm.errors.title && (
                                                <p className="text-red-500 text-sm mt-1">{assignmentForm.errors.title}</p>
                                            )}
                                        </div>
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                                Modul <span className="text-red-500">*</span>
                                            </label>
                                            <select
                                                value={assignmentForm.data.module_id}
                                                onChange={e => assignmentForm.setData('module_id', e.target.value)}
                                                className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                                            >
                                                <option value="">Pilih Modul...</option>
                                                {modules.map(module => (
                                                    <option key={module.id} value={module.id}>{module.title}</option>
                                                ))}
                                            </select>
                                            {assignmentForm.errors.module_id && (
                                                <p className="text-red-500 text-sm mt-1">{assignmentForm.errors.module_id}</p>
                                            )}
                                        </div>
                                    </div>

                                    {/* Class-specific Deadlines Section */}
                                    <div className="border-t pt-6">
                                        <h4 className="text-base md:text-lg font-medium text-gray-900 dark:text-white mb-4">
                                            Deadline per Kelas
                                        </h4>
                                        <p className="text-sm text-gray-600 dark:text-gray-400 mb-4">
                                            Tentukan deadline yang berbeda untuk setiap kelas
                                        </p>

                                        <div className="space-y-3 md:space-y-4">
                                            {classes.map((cls, index) => (
                                                <div key={cls.id} className="flex flex-col sm:flex-row sm:items-center gap-3 sm:gap-4 p-4 bg-gray-50 dark:bg-gray-700 rounded-lg">
                                                    <div className="flex-1">
                                                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                                            📚 Kelas {cls.name}
                                                        </label>
                                                        <input
                                                            type="datetime-local"
                                                            value={assignmentForm.data.class_deadlines[index]?.deadline || ''}
                                                            onChange={e => {
                                                                const newDeadlines = [...assignmentForm.data.class_deadlines];
                                                                newDeadlines[index] = {
                                                                    class_id: cls.id.toString(),
                                                                    deadline: e.target.value
                                                                };
                                                                assignmentForm.setData('class_deadlines', newDeadlines);
                                                            }}
                                                            className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                                                            required
                                                        />
                                                    </div>
                                                    {assignmentForm.data.class_deadlines[index]?.deadline && (
                                                        <div className="text-sm text-green-600 dark:text-green-400 flex items-center gap-1 sm:mt-6">
                                                            <CheckCircle className="h-4 w-4" />
                                                            <span>Set</span>
                                                        </div>
                                                    )}
                                                </div>
                                            ))}
                                        </div>

                                        {assignmentForm.errors.class_deadlines && (
                                            <p className="text-red-500 text-sm mt-2">{assignmentForm.errors.class_deadlines}</p>
                                        )}

                                        <div className="mt-4 p-4 bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg">
                                            <p className="text-sm text-blue-700 dark:text-blue-300">
                                                💡 <strong>Catatan:</strong> Setiap kelas dapat memiliki deadline yang berbeda.
                                                Mahasiswa akan melihat deadline sesuai dengan kelas mereka.
                                            </p>
                                        </div>
                                    </div>

                                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 md:gap-6">
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                                Skor Maksimal
                                            </label>
                                            <input
                                                type="number"
                                                value={assignmentForm.data.max_score}
                                                onChange={e => assignmentForm.setData('max_score', parseInt(e.target.value))}
                                                className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                                                min="1"
                                                max="100"
                                            />
                                            {assignmentForm.errors.max_score && (
                                                <p className="text-red-500 text-sm mt-1">{assignmentForm.errors.max_score}</p>
                                            )}
                                        </div>
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                                Poin Tepat Waktu
                                            </label>
                                            <input
                                                type="number"
                                                value={assignmentForm.data.point_reward_ontime}
                                                onChange={e => assignmentForm.setData('point_reward_ontime', parseInt(e.target.value))}
                                                className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                                                min="0"
                                            />
                                        </div>
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                                Poin Terlambat
                                            </label>
                                            <input
                                                type="number"
                                                value={assignmentForm.data.point_reward_late}
                                                onChange={e => assignmentForm.setData('point_reward_late', parseInt(e.target.value))}
                                                className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                                                min="0"
                                            />
                                        </div>
                                    </div>

                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                            Deskripsi Tugas <span className="text-red-500">*</span>
                                        </label>
                                        <textarea
                                            rows={4}
                                            value={assignmentForm.data.description}
                                            onChange={e => assignmentForm.setData('description', e.target.value)}
                                            className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                                            placeholder="Jelaskan detail tugas praktikum..."
                                        />
                                        {assignmentForm.errors.description && (
                                            <p className="text-red-500 text-sm mt-1">{assignmentForm.errors.description}</p>
                                        )}
                                    </div>

                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                            Petunjuk Pengerjaan (Opsional)
                                        </label>
                                        <textarea
                                            rows={6}
                                            value={assignmentForm.data.instructions}
                                            onChange={e => assignmentForm.setData('instructions', e.target.value)}
                                            className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                                            placeholder="1. Langkah pertama&#10;2. Langkah kedua&#10;3. dst..."
                                        />
                                    </div>

                                    <div className="flex items-center gap-3">
                                        <input
                                            type="checkbox"
                                            id="is_active"
                                            checked={assignmentForm.data.is_active}
                                            onChange={e => assignmentForm.setData('is_active', e.target.checked)}
                                            className="w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500"
                                        />
                                        <label htmlFor="is_active" className="text-sm font-medium text-gray-700 dark:text-gray-300">
                                            Aktifkan praktikum (mahasiswa dapat melihat dan mengumpulkan)
                                        </label>
                                    </div>
                                </div>
                            </div>

                            <div className="sticky bottom-0 p-4 md:p-6 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700 rounded-b-xl">
                                <div className="flex flex-col-reverse sm:flex-row items-stretch sm:items-center justify-end gap-3 sm:gap-4">
                                    <button
                                        onClick={() => setShowModal(false)}
                                        className="px-4 md:px-6 py-2 text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200 transition-colors border border-gray-300 dark:border-gray-600 rounded-lg"
                                    >
                                        Batal
                                    </button>
                                    <button
                                        onClick={() => {
                                            if (modalType === 'create') handleCreateAssignment();
                                            else handleUpdateAssignment();
                                        }}
                                        disabled={assignmentForm.processing}
                                        className="flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 md:px-6 py-2 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                                    >
                                        <Save className="h-4 w-4" />
                                        {assignmentForm.processing ? 'Menyimpan...' : 'Simpan'}
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                )}

                {/* Grade Modal */}
                {showModal && modalType === 'grade' && selectedSubmission && (
                    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50 overflow-y-auto">
                        <div className="bg-white dark:bg-gray-800 rounded-xl max-w-2xl w-full my-8">
                            <div className="sticky top-0 p-4 md:p-6 border-b border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 rounded-t-xl z-10">
                                <div className="flex items-center justify-between">
                                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                                        Beri Nilai
                                    </h3>
                                    <button
                                        onClick={() => setShowModal(false)}
                                        className="text-gray-500 hover:text-gray-700 dark:text-gray-400 dark:hover:text-gray-300"
                                    >
                                        <X className="h-6 w-6" />
                                    </button>
                                </div>
                            </div>

                            <div className="p-4 md:p-6 max-h-[calc(90vh-180px)] overflow-y-auto">
                                <div className="space-y-6">
                                    {/* Submission Info */}
                                    <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
                                        <h4 className="font-medium text-gray-900 dark:text-white mb-3">
                                            Informasi Pengumpulan
                                        </h4>
                                        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                                            <div>
                                                <span className="text-gray-600 dark:text-gray-400">Mahasiswa:</span>
                                                <p className="font-medium text-gray-900 dark:text-white">
                                                    {selectedSubmission.studentName}
                                                </p>
                                            </div>
                                            <div>
                                                <span className="text-gray-600 dark:text-gray-400">NIM:</span>
                                                <p className="font-medium text-gray-900 dark:text-white">
                                                    {selectedSubmission.nim}
                                                </p>
                                            </div>
                                            <div className="sm:col-span-2">
                                                <span className="text-gray-600 dark:text-gray-400">File:</span>
                                                <p className="font-medium text-gray-900 dark:text-white truncate">
                                                    {selectedSubmission.fileName}
                                                </p>
                                            </div>
                                            <div>
                                                <span className="text-gray-600 dark:text-gray-400">Ukuran:</span>
                                                <p className="font-medium text-gray-900 dark:text-white">
                                                    {selectedSubmission.fileSize}
                                                </p>
                                            </div>
                                            <div>
                                                <span className="text-gray-600 dark:text-gray-400">Dikumpulkan:</span>
                                                <p className="font-medium text-gray-900 dark:text-white text-xs md:text-sm">
                                                    {new Date(selectedSubmission.submittedAt).toLocaleString('id-ID')}
                                                </p>
                                            </div>
                                            <div className="sm:col-span-2">
                                                <span className="text-gray-600 dark:text-gray-400">Status:</span>
                                                <p className={`font-medium ${
                                                    selectedSubmission.isLate ? 'text-red-500' : 'text-green-500'
                                                }`}>
                                                    {selectedSubmission.isLate
                                                        ? `Terlambat ${Math.abs(Math.floor(selectedSubmission.daysLate))} hari`
                                                        : `${Math.floor(selectedSubmission.daysEarly)} hari lebih awal`
                                                    }
                                                </p>
                                            </div>
                                        </div>
                                    </div>

                                    {/* Grade Input */}
                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                            Nilai (0-100) <span className="text-red-500">*</span>
                                        </label>
                                        <input
                                            type="number"
                                            value={gradeForm.data.score}
                                            onChange={e => gradeForm.setData('score', e.target.value)}
                                            className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white text-2xl font-bold text-center focus:ring-2 focus:ring-blue-500"
                                            placeholder="85"
                                            min="0"
                                            max="100"
                                        />
                                        {gradeForm.errors.score && (
                                            <p className="text-red-500 text-sm mt-1">{gradeForm.errors.score}</p>
                                        )}
                                        <div className="flex justify-between mt-2 text-xs text-gray-500">
                                            <span>Minimum: 0</span>
                                            <span>Maksimum: 100</span>
                                        </div>
                                    </div>

                                    {/* Feedback Input */}
                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                            Feedback & Komentar <span className="text-gray-500">(Opsional)</span>
                                        </label>
                                        <textarea
                                            rows={6}
                                            value={gradeForm.data.feedback}
                                            onChange={e => gradeForm.setData('feedback', e.target.value)}
                                            className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                                            placeholder="Berikan feedback konstruktif untuk mahasiswa...&#10;&#10;Contoh:&#10;- Implementasi algoritma sudah benar&#10;- Struktur kode rapi dan mudah dibaca&#10;- Dokumentasi perlu ditambahkan&#10;- dll"
                                        />
                                        <p className="text-xs text-gray-500 mt-1">
                                            Feedback akan membantu mahasiswa memahami kekuatan dan area yang perlu ditingkatkan
                                        </p>
                                    </div>

                                    {/* Info Box */}
                                    <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
                                        <div className="flex items-start gap-3">
                                            <AlertTriangle className="h-5 w-5 text-blue-600 mt-0.5 flex-shrink-0" />
                                            <div>
                                                <span className="text-sm font-medium text-blue-800 dark:text-blue-200 block mb-1">
                                                    Informasi Penilaian
                                                </span>
                                                <p className="text-sm text-blue-700 dark:text-blue-300">
                                                    Nilai yang Anda berikan akan langsung tersimpan. Pastikan nilai dan feedback sudah sesuai sebelum menyimpan.
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div className="sticky bottom-0 p-4 md:p-6 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700 rounded-b-xl">
                                <div className="flex flex-col-reverse sm:flex-row items-stretch sm:items-center justify-end gap-3 sm:gap-4">
                                    <button
                                        onClick={() => setShowModal(false)}
                                        className="px-4 py-2 text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200 transition-colors border border-gray-300 dark:border-gray-600 rounded-lg"
                                    >
                                        Batal
                                    </button>
                                    <button
                                        onClick={() => openPdfPreview(selectedSubmission)}
                                        className="flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors"
                                    >
                                        <Eye className="h-4 w-4" />
                                        Lihat File
                                    </button>
                                    <button
                                        onClick={handleGradeSubmission}
                                        disabled={gradeForm.processing || !gradeForm.data.score}
                                        className="flex items-center justify-center gap-2 bg-green-600 hover:bg-green-700 text-white px-6 py-2 rounded-lg transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                                    >
                                        <Save className="h-4 w-4" />
                                        {gradeForm.processing ? 'Menyimpan...' : 'Simpan Nilai'}
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                )}
            </div>
        </AppLayout>
    );
}
