import React, { useState, useEffect } from 'react';
import AppLayout from '@/layouts/app-layout';
import { router } from '@inertiajs/react';
import { type BreadcrumbItem } from '@/types';
import toast from 'react-hot-toast';
import { useCustomToast } from '@/hooks/use-toast';
import {
    ClipboardList, Plus, Edit3, Trash2, Eye, Search, Users, Clock,
    CheckCircle, X, Save, BarChart3, Target,
    Power, PowerOff, ArrowLeft, Award, BookOpen, AlertCircle
} from 'lucide-react';

const breadcrumbs: BreadcrumbItem[] = [
    { title: 'Dashboard', href: '/instructor/dashboard' },
    { title: 'Quiz Management', href: '/instructor/quiz' },
];

interface Quiz {
    id: number;
    title: string;
    description?: string;
    moduleId: number;
    moduleName: string;
    totalQuestions: number;
    timeLimit: number;
    attempts: number;
    averageScore: number;
    status: 'active' | 'draft';
    createdAt: string;
    deadline: string;
}

interface Module {
    id: number;
    title: string;
}

interface Question {
    id?: number;
    question: string;
    type: 'multiple_choice';
    options: string[];
    correct_answer: string;
    points: number;
}

interface QuizResult {
    id: number;
    studentName: string;
    nim: string;
    quizId: number;
    quizTitle: string;
    score: number;
    pointsEarned: number;
    completedAt: string;
}

interface InstructorQuizManagementProps {
    quizzes?: Quiz[];
    modules?: Module[];
}

const InstructorQuizManagement: React.FC<InstructorQuizManagementProps> = ({
    quizzes: initialQuizzes = [],
    modules: initialModules = []
}) => {
    const customToast = useCustomToast();

    const [activeTab, setActiveTab] = useState('quizzes');
    const [showModal, setShowModal] = useState(false);
    const [modalType, setModalType] = useState('');
    const [selectedQuiz, setSelectedQuiz] = useState<Quiz | null>(null);
    const [searchTerm, setSearchTerm] = useState('');
    const [quizzes, setQuizzes] = useState<Quiz[]>(() => {
        if (!initialQuizzes) return [];
        if (Array.isArray(initialQuizzes)) return initialQuizzes;
        if (typeof initialQuizzes === 'object' && 'data' in initialQuizzes) {
            return Array.isArray(initialQuizzes.data) ? initialQuizzes.data : [];
        }
        return [];
    });
    const [modules] = useState<Module[]>(() => {
        if (!initialModules) return [];
        if (Array.isArray(initialModules)) return initialModules;
        return [];
    });
    const [results, setResults] = useState<QuizResult[]>([]);
    const [analytics, setAnalytics] = useState<any>(null);
    const [loading, setLoading] = useState(false);
    const [selectedResultDetail, setSelectedResultDetail] = useState<QuizResult | null>(null);

    const [quizForm, setQuizForm] = useState({
        title: '',
        description: '',
        module_id: '',
        time_limit: 30,
        questions: [] as Question[]
    });

    const [currentQuestion, setCurrentQuestion] = useState<Question>({
        question: '',
        type: 'multiple_choice',
        options: ['', '', '', ''],
        correct_answer: 'A',
        points: 10
    });

    useEffect(() => {
        if (initialQuizzes) {
            if (Array.isArray(initialQuizzes)) {
                setQuizzes(initialQuizzes);
            } else if (typeof initialQuizzes === 'object' && 'data' in initialQuizzes) {
                setQuizzes(Array.isArray(initialQuizzes.data) ? initialQuizzes.data : []);
            }
        }
    }, [initialQuizzes]);

    useEffect(() => {
        if (activeTab === 'analytics') {
            loadAnalytics();
        }
    }, [activeTab]);

    const loadResults = async (quizId: number) => {
        setLoading(true);
        const loadingToast = toast.loading('Memuat hasil quiz...');

        try {
            const response = await fetch(`/instructor/quiz/results/data?quiz_id=${quizId}`);
            if (response.ok) {
                const data = await response.json();
                setResults(data.results || []);
                toast.success('Hasil quiz berhasil dimuat!', { id: loadingToast });
            } else {
                toast.error('Gagal memuat hasil quiz', { id: loadingToast });
            }
        } catch (error) {
            console.error('Error loading results:', error);
            toast.error('Terjadi kesalahan saat memuat hasil', { id: loadingToast });
        } finally {
            setLoading(false);
        }
    };

    const loadAnalytics = async () => {
        setLoading(true);
        const loadingToast = toast.loading('Memuat data analitik...');

        try {
            const response = await fetch('/instructor/quiz/analytics/data');
            if (response.ok) {
                const data = await response.json();
                setAnalytics(data);
                toast.success('Data analitik berhasil dimuat!', { id: loadingToast });
            } else {
                toast.error('Gagal memuat data analitik', { id: loadingToast });
            }
        } catch (error) {
            console.error('Error loading analytics:', error);
            toast.error('Terjadi kesalahan saat memuat analitik', { id: loadingToast });
        } finally {
            setLoading(false);
        }
    };

    const loadQuizDetail = async (quiz: Quiz) => {
        const loadingToast = toast.loading('Memuat detail quiz...');

        try {
            const response = await fetch(`/instructor/quiz/${quiz.id}`);
            if (response.ok) {
                const data = await response.json();
                setQuizForm({
                    title: data.quiz.title || '',
                    description: data.quiz.description || '',
                    module_id: data.quiz.module_id?.toString() || '',
                    time_limit: data.quiz.time_limit || 30,
                    questions: Array.isArray(data.quiz.questions) ? data.quiz.questions : []
                });
                toast.success('Detail quiz berhasil dimuat!', { id: loadingToast });
            } else {
                toast.error('Gagal memuat detail quiz', { id: loadingToast });
            }
        } catch (error) {
            console.error('Error loading quiz detail:', error);
            toast.error('Terjadi kesalahan saat memuat detail', { id: loadingToast });
        }
    };

    const handleCreateQuiz = () => {
        setModalType('create');
        setSelectedQuiz(null);
        setQuizForm({
            title: '',
            description: '',
            module_id: '',
            time_limit: 30,
            questions: []
        });
        setCurrentQuestion({
            question: '',
            type: 'multiple_choice',
            options: ['', '', '', ''],
            correct_answer: 'A',
            points: 10
        });
        setShowModal(true);
    };

    const handleEditQuiz = async (quiz: Quiz) => {
        setSelectedQuiz(quiz);
        setModalType('edit');
        await loadQuizDetail(quiz);
        setShowModal(true);
    };

    const handleViewQuiz = async (quiz: Quiz) => {
        setSelectedQuiz(quiz);
        setModalType('view');
        await loadQuizDetail(quiz);
        setShowModal(true);
    };

    const openQuizResults = (quiz: Quiz) => {
        setSelectedQuiz(quiz);
        loadResults(quiz.id);
    };

    const handleDeleteQuiz = (quiz: Quiz) => {
        if (confirm(`Apakah Anda yakin ingin menghapus quiz "${quiz.title}"?`)) {
            customToast.withLoading(
                new Promise((resolve, reject) => {
                    router.delete(`/instructor/quiz/${quiz.id}`, {
                        onSuccess: () => {
                            setQuizzes(prevQuizzes => prevQuizzes.filter(q => q.id !== quiz.id));
                            resolve(true);
                        },
                        onError: () => reject()
                    });
                }),
                {
                    loading: 'Menghapus quiz...',
                    success: `Quiz "${quiz.title}" berhasil dihapus! 🗑️`,
                    error: 'Gagal menghapus quiz'
                }
            );
        }
    };

    const handleToggleStatus = (quiz: Quiz) => {
        const newStatus = quiz.status === 'active' ? 'draft' : 'active';
        const action = newStatus === 'active' ? 'mengaktifkan' : 'menonaktifkan';

        customToast.withLoading(
            new Promise((resolve, reject) => {
                router.patch(`/instructor/quiz/${quiz.id}/toggle-status`, {}, {
                    onSuccess: () => {
                        setQuizzes(prevQuizzes => prevQuizzes.map(q =>
                            q.id === quiz.id
                                ? { ...q, status: newStatus }
                                : q
                        ));
                        resolve(true);
                    },
                    onError: () => reject()
                });
            }),
            {
                loading: `${action.charAt(0).toUpperCase() + action.slice(1)} quiz...`,
                success: `Quiz berhasil ${newStatus === 'active' ? 'diaktifkan' : 'dinonaktifkan'}! ${newStatus === 'active' ? '✅' : '📝'}`,
                error: `Gagal ${action} quiz`
            }
        );
    };

    const addQuestion = () => {
        if (!currentQuestion.question.trim()) {
            toast.error('Pertanyaan tidak boleh kosong!');
            return;
        }

        const validOptions = currentQuestion.options.filter(opt => opt.trim());
        if (validOptions.length < 2) {
            toast.error('Minimal harus ada 2 pilihan jawaban!');
            return;
        }

        setQuizForm(prev => ({
            ...prev,
            questions: [...prev.questions, { ...currentQuestion }]
        }));

        toast.success('Soal berhasil ditambahkan!');

        setCurrentQuestion({
            question: '',
            type: 'multiple_choice',
            options: ['', '', '', ''],
            correct_answer: 'A',
            points: 10
        });
    };

    const removeQuestion = (index: number) => {
        setQuizForm(prev => ({
            ...prev,
            questions: prev.questions.filter((_, i) => i !== index)
        }));
        toast.success('Soal berhasil dihapus');
    };

    const handleSubmitQuiz = () => {
        if (!quizForm.title.trim()) {
            toast.error('Judul quiz tidak boleh kosong!');
            return;
        }
        if (!quizForm.module_id) {
            toast.error('Modul harus dipilih!');
            return;
        }
        if (quizForm.questions.length === 0) {
            toast.error('Minimal harus ada 1 soal!');
            return;
        }

        const data = {
            module_id: parseInt(quizForm.module_id),
            title: quizForm.title,
            description: quizForm.description,
            time_limit: quizForm.time_limit,
            questions: JSON.stringify(quizForm.questions)
        };

        if (modalType === 'create') {
            customToast.withLoading(
                new Promise((resolve, reject) => {
                    router.post('/instructor/quiz', data, {
                        onSuccess: () => {
                            setShowModal(false);
                            router.reload({ only: ['quizzes'] });
                            resolve(true);
                        },
                        onError: (errors) => {
                            console.error('Create quiz error:', errors);
                            reject(errors);
                        }
                    });
                }),
                {
                    loading: 'Membuat quiz...',
                    success: 'Quiz berhasil dibuat! 🎉',
                    error: 'Gagal membuat quiz. Periksa data yang diinput.'
                }
            );
        } else if (modalType === 'edit' && selectedQuiz) {
            customToast.withLoading(
                new Promise((resolve, reject) => {
                    router.put(`/instructor/quiz/${selectedQuiz.id}`, data, {
                        onSuccess: () => {
                            setShowModal(false);
                            router.reload({ only: ['quizzes'] });
                            resolve(true);
                        },
                        onError: (errors) => {
                            console.error('Update quiz error:', errors);
                            reject(errors);
                        }
                    });
                }),
                {
                    loading: 'Memperbarui quiz...',
                    success: 'Quiz berhasil diperbarui! ✅',
                    error: 'Gagal memperbarui quiz. Periksa data yang diinput.'
                }
            );
        }
    };

    // Filter quizzes by search term
    const filteredQuizzes = quizzes.filter(quiz =>
        quiz.title?.toLowerCase().includes(searchTerm.toLowerCase()) ||
        quiz.moduleName?.toLowerCase().includes(searchTerm.toLowerCase())
    );

    // Group by module
    const quizzesByModule = modules.map(module => {
        const moduleQuizzes = filteredQuizzes.filter(q => q.moduleId === module.id);
        return {
            module,
            quizzes: moduleQuizzes,
            totalAttempts: moduleQuizzes.reduce((sum, q) => sum + q.attempts, 0),
        };
    }).filter(m => m.quizzes.length > 0);

    const QuestionEditor = () => (
        <div className="space-y-4">
            <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Pertanyaan <span className="text-red-500">*</span>
                </label>
                <textarea
                    value={currentQuestion.question}
                    onChange={(e) => setCurrentQuestion(prev => ({...prev, question: e.target.value}))}
                    className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                    rows={3}
                    placeholder="Masukkan pertanyaan..."
                />
            </div>

            <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Pilihan Jawaban <span className="text-red-500">*</span>
                </label>
                <div className="space-y-3">
                    {currentQuestion.options.map((option, index) => (
                        <div key={index} className="flex items-center gap-3">
                            <input
                                type="radio"
                                name="correctAnswer"
                                checked={currentQuestion.correct_answer === String.fromCharCode(65 + index)}
                                onChange={() => setCurrentQuestion(prev => ({
                                    ...prev,
                                    correct_answer: String.fromCharCode(65 + index)
                                }))}
                                className="text-blue-600 focus:ring-blue-500"
                            />
                            <span className="text-sm text-gray-500 dark:text-gray-400 w-4 font-medium">
                                {String.fromCharCode(65 + index)}.
                            </span>
                            <input
                                type="text"
                                value={option}
                                onChange={(e) => {
                                    const newOptions = [...currentQuestion.options];
                                    newOptions[index] = e.target.value;
                                    setCurrentQuestion(prev => ({...prev, options: newOptions}));
                                }}
                                className="flex-1 p-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                                placeholder={`Pilihan ${String.fromCharCode(65 + index)}`}
                            />
                        </div>
                    ))}
                </div>
                <p className="text-xs text-gray-500 dark:text-gray-400 mt-2">
                    💡 Pilih opsi yang benar dengan mencentang radio button
                </p>
            </div>

            <div>
                <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                    Poin
                </label>
                <input
                    type="number"
                    value={currentQuestion.points}
                    onChange={(e) => setCurrentQuestion(prev => ({...prev, points: parseInt(e.target.value) || 10}))}
                    className="w-32 p-2 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                    min="1"
                    max="100"
                />
            </div>

            <div className="flex justify-end pt-4">
                <button
                    onClick={addQuestion}
                    disabled={!currentQuestion.question.trim()}
                    className="flex items-center gap-2 bg-green-600 hover:bg-green-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white px-4 py-2 rounded-lg transition-colors"
                >
                    <Plus className="h-4 w-4" />
                    Tambah Soal
                </button>
            </div>
        </div>
    );

    const QuestionList = () => (
        <div className="space-y-3">
            {quizForm.questions.map((question, index) => (
                <div key={index} className="border border-gray-200 dark:border-gray-600 rounded-lg p-4 bg-gray-50 dark:bg-gray-700">
                    <div className="flex justify-between items-start mb-2">
                        <h4 className="font-medium text-gray-900 dark:text-white">
                            Soal {index + 1} <span className="text-sm text-gray-500">({question.points} poin)</span>
                        </h4>
                        <button
                            onClick={() => removeQuestion(index)}
                            className="text-red-500 hover:text-red-700 transition-colors p-1 hover:bg-red-50 dark:hover:bg-red-900/20 rounded"
                        >
                            <Trash2 className="h-4 w-4" />
                        </button>
                    </div>
                    <p className="text-sm text-gray-700 dark:text-gray-300 mb-3">
                        {question.question}
                    </p>
                    {Array.isArray(question.options) && (
                        <div className="text-xs space-y-1">
                            {question.options.map((option, optIndex) => (
                                <div key={optIndex} className={`px-3 py-2 rounded ${
                                    String.fromCharCode(65 + optIndex) === question.correct_answer
                                        ? 'bg-green-100 dark:bg-green-900/30 text-green-800 dark:text-green-300 font-medium'
                                        : 'bg-white dark:bg-gray-600 text-gray-700 dark:text-gray-300'
                                }`}>
                                    <span className="font-semibold">{String.fromCharCode(65 + optIndex)}.</span> {option}
                                    {String.fromCharCode(65 + optIndex) === question.correct_answer && ' ✓'}
                                </div>
                            ))}
                        </div>
                    )}
                </div>
            ))}
        </div>
    );

    return (
        <AppLayout breadcrumbs={breadcrumbs}>
            <div className="flex h-full flex-1 flex-col gap-6 p-4 md:p-6">
                {/* Header */}
                <div className="mb-4 md:mb-8">
                    <h1 className="text-2xl md:text-3xl font-bold text-gray-900 dark:text-white mb-2">
                        Quiz Management
                    </h1>
                    <p className="text-sm md:text-base text-gray-600 dark:text-gray-400">
                        Kelola quiz dan monitor hasil pengerjaan mahasiswa
                    </p>
                </div>

                {/* Navigation Tabs */}
                <div className="flex border-b border-gray-200 dark:border-gray-700 mb-6 overflow-x-auto">
                    {[
                        { id: 'quizzes', label: 'Daftar Quiz', icon: ClipboardList },
                        { id: 'analytics', label: 'Analisis', icon: BarChart3 }
                    ].map((tab) => {
                        const Icon = tab.icon;
                        return (
                            <button
                                key={tab.id}
                                onClick={() => {
                                    setActiveTab(tab.id);
                                    setSelectedQuiz(null);
                                }}
                                className={`flex items-center gap-2 px-4 md:px-6 py-3 font-medium transition-colors whitespace-nowrap ${
                                    activeTab === tab.id
                                        ? 'text-blue-600 dark:text-blue-400 border-b-2 border-blue-600'
                                        : 'text-gray-500 dark:text-gray-400 hover:text-gray-700'
                                }`}
                            >
                                <Icon className="h-4 w-4 md:h-5 md:w-5" />
                                <span className="hidden sm:inline">{tab.label}</span>
                            </button>
                        );
                    })}
                </div>

                {/* Quizzes Tab */}
                {activeTab === 'quizzes' && !selectedQuiz && (
                    <div className="space-y-6">
                        {/* Search and Create */}
                        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-4">
                            <div className="relative flex-1 max-w-md">
                                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                                <input
                                    type="text"
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    placeholder="Cari quiz atau modul..."
                                    className="pl-10 pr-4 py-2 w-full border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                                />
                            </div>
                            <button
                                onClick={handleCreateQuiz}
                                className="flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors whitespace-nowrap"
                            >
                                <Plus className="h-4 w-4" />
                                <span className="hidden sm:inline">Buat Quiz Baru</span>
                                <span className="sm:hidden">Buat Quiz</span>
                            </button>
                        </div>

                        {/* Quiz List */}
                        {quizzesByModule.length === 0 ? (
                            <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-12 text-center">
                                <ClipboardList className="h-16 w-16 mx-auto mb-4 text-gray-400" />
                                <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-2">
                                    {searchTerm ? 'Quiz Tidak Ditemukan' : 'Belum Ada Quiz'}
                                </h3>
                                <p className="text-gray-500 mb-6">
                                    {searchTerm
                                        ? 'Coba kata kunci lain atau buat quiz baru'
                                        : 'Mulai dengan membuat quiz pertama untuk mahasiswa Anda'
                                    }
                                </p>
                                {!searchTerm && (
                                    <button
                                        onClick={handleCreateQuiz}
                                        className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg"
                                    >
                                        <Plus className="h-5 w-5" />
                                        Buat Quiz Pertama
                                    </button>
                                )}
                            </div>
                        ) : (
                            quizzesByModule.map(({ module, quizzes: moduleQuizzes }) => (
                                <div key={module.id} className="space-y-4">
                                    <div className="flex items-center justify-between">
                                        <h2 className="text-lg md:text-xl font-semibold text-gray-900 dark:text-white">
                                            {module.title}
                                        </h2>
                                        <span className="text-xs md:text-sm text-gray-500">
                                            {moduleQuizzes.length} quiz
                                        </span>
                                    </div>

                                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 md:gap-6">
                                        {moduleQuizzes.map((quiz) => (
                                            <div
                                                key={quiz.id}
                                                className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 p-4 md:p-6 hover:shadow-lg transition-all cursor-pointer"
                                                onClick={() => openQuizResults(quiz)}
                                            >
                                                <div className="flex items-start justify-between mb-4">
                                                    <div className="flex-1 min-w-0">
                                                        <div className="flex items-center gap-2 mb-2 flex-wrap">
                                                            <h3 className="text-base md:text-lg font-semibold text-gray-900 dark:text-white truncate">
                                                                {quiz.title}
                                                            </h3>
                                                            <span className={`px-2 py-1 text-xs rounded-full flex-shrink-0 ${
                                                                quiz.status === 'active'
                                                                    ? 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300'
                                                                    : 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-300'
                                                            }`}>
                                                                {quiz.status === 'active' ? 'Aktif' : 'Draft'}
                                                            </span>
                                                        </div>
                                                    </div>
                                                    <div className="flex items-center gap-1 ml-2" onClick={(e) => e.stopPropagation()}>
                                                        <button
                                                            onClick={() => handleToggleStatus(quiz)}
                                                            className={`p-2 rounded-lg transition-colors ${
                                                                quiz.status === 'active'
                                                                    ? 'text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20'
                                                                    : 'text-green-500 hover:bg-green-50 dark:hover:bg-green-900/20'
                                                            }`}
                                                            title={quiz.status === 'active' ? 'Nonaktifkan' : 'Aktifkan'}
                                                        >
                                                            {quiz.status === 'active' ? <PowerOff className="h-4 w-4" /> : <Power className="h-4 w-4" />}
                                                        </button>
                                                        <button
                                                            onClick={() => handleViewQuiz(quiz)}
                                                            className="p-2 text-blue-600 hover:bg-blue-50 dark:hover:bg-blue-900/20 rounded-lg transition-colors"
                                                            title="Lihat Detail"
                                                        >
                                                            <Eye className="h-4 w-4" />
                                                        </button>
                                                        <button
                                                            onClick={() => handleEditQuiz(quiz)}
                                                            className="p-2 text-green-600 hover:bg-green-50 dark:hover:bg-green-900/20 rounded-lg transition-colors"
                                                            title="Edit Quiz"
                                                        >
                                                            <Edit3 className="h-4 w-4" />
                                                        </button>
                                                        <button
                                                            onClick={() => handleDeleteQuiz(quiz)}
                                                            className="p-2 text-red-600 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg transition-colors"
                                                            title="Hapus Quiz"
                                                        >
                                                            <Trash2 className="h-4 w-4" />
                                                        </button>
                                                    </div>
                                                </div>

                                                <div className="grid grid-cols-2 gap-3 mb-4">
                                                    <div className="text-center p-3 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                                                        <BookOpen className="h-5 w-5 mx-auto mb-1 text-blue-600" />
                                                        <p className="text-xl md:text-2xl font-bold text-blue-600">{quiz.totalQuestions}</p>
                                                        <p className="text-xs text-gray-600 dark:text-gray-400">Soal</p>
                                                    </div>
                                                    <div className="text-center p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                                                        <Users className="h-5 w-5 mx-auto mb-1 text-green-600"/>
                                                        <p className="text-xl md:text-2xl font-bold text-green-600">{quiz.attempts}</p>
                                                        <p className="text-xs text-gray-600 dark:text-gray-400">Dikerjakan</p>
                                                    </div>
                                                </div>
                                                <div className="flex items-center justify-between text-sm text-gray-500 dark:text-gray-400">
                                                <div className="flex items-center gap-1">
                                                <Clock className="h-4 w-4" />
                                                <span>{quiz.timeLimit} menit</span>
                                            </div>
                                            <div className="flex items-center gap-1">
                                                <Award className="h-4 w-4" />
                                                <span>Avg: {quiz.averageScore}</span>
                                            </div>
                                            </div>
                                        </div>
                                    ))}
                                </div>
                            </div>
                        ))
                    )}
                </div>
            )}

            {/* Quiz Results Detail */}
            {activeTab === 'quizzes' && selectedQuiz && (
                <div className="space-y-6">
                    <div className="flex items-center gap-4 mb-6">
                        <button
                            onClick={() => setSelectedQuiz(null)}
                            className="flex items-center gap-2 text-gray-600 dark:text-gray-400 hover:text-gray-800 dark:hover:text-gray-200 transition-colors"
                        >
                            <ArrowLeft className="h-5 w-5" />
                            <span className="hidden sm:inline">Kembali</span>
                        </button>
                        <div className="flex-1 min-w-0">
                            <h2 className="text-xl md:text-2xl font-bold text-gray-900 dark:text-white truncate">
                                {selectedQuiz.title}
                            </h2>
                            <p className="text-sm text-gray-500 dark:text-gray-400">{selectedQuiz.moduleName}</p>
                        </div>
                    </div>

                    {/* Stats Cards */}
                    <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 md:gap-4">
                        <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg border border-blue-200 dark:border-blue-800">
                            <Users className="h-5 w-5 md:h-6 md:w-6 text-blue-600 mb-2" />
                            <p className="text-xl md:text-2xl font-bold text-blue-600">{results.length}</p>
                            <p className="text-xs md:text-sm text-gray-600 dark:text-gray-400">Total Attempts</p>
                        </div>
                        <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg border border-green-200 dark:border-green-800">
                            <CheckCircle className="h-5 w-5 md:h-6 md:w-6 text-green-600 mb-2" />
                            <p className="text-xl md:text-2xl font-bold text-green-600">
                                {results.filter(r => r.score >= 60).length}
                            </p>
                            <p className="text-xs md:text-sm text-gray-600 dark:text-gray-400">Lulus</p>
                        </div>
                        <div className="bg-purple-50 dark:bg-purple-900/20 p-4 rounded-lg border border-purple-200 dark:border-purple-800">
                            <Award className="h-5 w-5 md:h-6 md:w-6 text-purple-600 mb-2" />
                            <p className="text-xl md:text-2xl font-bold text-purple-600">
                                {results.length > 0
                                    ? Math.round(results.reduce((sum, r) => sum + r.score, 0) / results.length)
                                    : 0}
                            </p>
                            <p className="text-xs md:text-sm text-gray-600 dark:text-gray-400">Rata-rata</p>
                        </div>
                        <div className="bg-orange-50 dark:bg-orange-900/20 p-4 rounded-lg border border-orange-200 dark:border-orange-800">
                            <Target className="h-5 w-5 md:h-6 md:w-6 text-orange-600 mb-2" />
                            <p className="text-xl md:text-2xl font-bold text-orange-600">
                                {results.length > 0
                                    ? Math.round((results.filter(r => r.score >= 60).length / results.length) * 100)
                                    : 0}%
                            </p>
                            <p className="text-xs md:text-sm text-gray-600 dark:text-gray-400">Pass Rate</p>
                        </div>
                    </div>

                    {/* Results List */}
                    <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 overflow-hidden">
                        <div className="p-4 border-b border-gray-200 dark:border-gray-700">
                            <h3 className="font-semibold text-gray-900 dark:text-white">Hasil Quiz Mahasiswa</h3>
                        </div>
                        <div className="divide-y divide-gray-200 dark:divide-gray-700">
                            {loading ? (
                                <div className="p-8 text-center">
                                    <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600 mx-auto"></div>
                                    <p className="text-sm text-gray-500 mt-2">Memuat data...</p>
                                </div>
                            ) : results.length === 0 ? (
                                <div className="p-8 text-center text-gray-500">
                                    <ClipboardList className="h-12 w-12 mx-auto mb-2 text-gray-400" />
                                    <p>Belum ada mahasiswa yang mengerjakan quiz ini</p>
                                </div>
                            ) : (
                                results.map((result) => (
                                    <div key={result.id} className="p-4 md:p-6 hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                                        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                                            <div className="flex-1 min-w-0">
                                                <div className="flex flex-wrap items-center gap-2 mb-2">
                                                    <h4 className="font-semibold text-gray-900 dark:text-white">
                                                        {result.studentName}
                                                    </h4>
                                                    <span className="text-sm text-gray-500 dark:text-gray-400">
                                                        {result.nim}
                                                    </span>
                                                    <span className={`px-2 py-1 text-xs rounded-full ${
                                                        result.score >= 80
                                                            ? 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300'
                                                            : result.score >= 60
                                                            ? 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-300'
                                                            : 'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300'
                                                    }`}>
                                                        Skor: {result.score}
                                                    </span>
                                                </div>
                                                <div className="flex flex-wrap items-center gap-2 text-sm text-gray-600 dark:text-gray-400">
                                                    <span>Poin: +{result.pointsEarned}</span>
                                                    <span className="hidden sm:inline">•</span>
                                                    <span className="text-xs sm:text-sm">{new Date(result.completedAt).toLocaleString('id-ID')}</span>
                                                </div>
                                            </div>
                                            <button
                                                onClick={() => setSelectedResultDetail(result)}
                                                className="flex items-center justify-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors whitespace-nowrap"
                                            >
                                                <Eye className="h-4 w-4" />
                                                <span className="hidden sm:inline">Lihat Detail</span>
                                                <span className="sm:hidden">Detail</span>
                                            </button>
                                        </div>
                                    </div>
                                ))
                            )}
                        </div>
                    </div>
                </div>
            )}

            {/* Analytics Tab */}
            {activeTab === 'analytics' && (
                <div className="space-y-6">
                    <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
                        Analisis Performa Quiz
                    </h2>

                    {loading ? (
                        <div className="flex justify-center py-8">
                            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
                        </div>
                    ) : analytics ? (
                        <>
                            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
                                <div className="bg-white dark:bg-gray-800 p-4 md:p-6 rounded-xl border border-gray-200 dark:border-gray-700">
                                    <div className="flex items-center justify-between mb-2">
                                        <h3 className="text-sm font-medium text-gray-900 dark:text-white">Total Attempt</h3>
                                        <Users className="h-5 w-5 text-blue-500" />
                                    </div>
                                    <p className="text-2xl md:text-3xl font-bold text-blue-600">
                                        {analytics.overall_stats?.total_attempts || 0}
                                    </p>
                                    <p className="text-xs md:text-sm text-gray-500 mt-2">Dari semua quiz</p>
                                </div>

                                <div className="bg-white dark:bg-gray-800 p-4 md:p-6 rounded-xl border border-gray-200 dark:border-gray-700">
                                    <div className="flex items-center justify-between mb-2">
                                        <h3 className="text-sm font-medium text-gray-900 dark:text-white">Rata-rata Skor</h3>
                                        <Target className="h-5 w-5 text-green-500" />
                                    </div>
                                    <p className="text-2xl md:text-3xl font-bold text-green-600">
                                        {analytics.overall_stats?.average_score || 0}
                                    </p>
                                    <p className="text-xs md:text-sm text-gray-500 mt-2">Dari 100</p>
                                </div>

                                <div className="bg-white dark:bg-gray-800 p-4 md:p-6 rounded-xl border border-gray-200 dark:border-gray-700">
                                    <div className="flex items-center justify-between mb-2">
                                        <h3 className="text-sm font-medium text-gray-900 dark:text-white">Tingkat Kelulusan</h3>
                                        <CheckCircle className="h-5 w-5 text-orange-500" />
                                    </div>
                                    <p className="text-2xl md:text-3xl font-bold text-orange-600">
                                        {analytics.overall_stats?.pass_rate || 0}%
                                    </p>
                                    <p className="text-xs md:text-sm text-gray-500 mt-2">Skor ≥ 60</p>
                                </div>

                                <div className="bg-white dark:bg-gray-800 p-4 md:p-6 rounded-xl border border-gray-200 dark:border-gray-700">
                                    <div className="flex items-center justify-between mb-2">
                                        <h3 className="text-sm font-medium text-gray-900 dark:text-white">Waktu Rata-rata</h3>
                                        <Clock className="h-5 w-5 text-purple-500" />
                                    </div>
                                    <p className="text-2xl md:text-3xl font-bold text-purple-600">
                                        {analytics.overall_stats?.average_time || 0}
                                    </p>
                                    <p className="text-xs md:text-sm text-gray-500 mt-2">Menit per quiz</p>
                                </div>
                            </div>

                            <div className="bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 overflow-hidden">
                                <div className="px-4 md:px-6 py-4 border-b border-gray-200 dark:border-gray-700">
                                    <h3 className="font-medium text-gray-900 dark:text-white">Analisis Per Quiz</h3>
                                </div>
                                <div className="overflow-x-auto">
                                    <table className="w-full">
                                        <thead className="bg-gray-50 dark:bg-gray-700">
                                            <tr>
                                                <th className="px-4 md:px-6 py-3 text-left text-xs md:text-sm font-medium text-gray-500 dark:text-gray-400">Quiz</th>
                                                <th className="px-4 md:px-6 py-3 text-left text-xs md:text-sm font-medium text-gray-500 dark:text-gray-400">Modul</th>
                                                <th className="px-4 md:px-6 py-3 text-left text-xs md:text-sm font-medium text-gray-500 dark:text-gray-400">Attempts</th>
                                                <th className="px-4 md:px-6 py-3 text-left text-xs md:text-sm font-medium text-gray-500 dark:text-gray-400">Rata-rata</th>
                                                <th className="px-4 md:px-6 py-3 text-left text-xs md:text-sm font-medium text-gray-500 dark:text-gray-400">Pass Rate</th>
                                                <th className="px-4 md:px-6 py-3 text-left text-xs md:text-sm font-medium text-gray-500 dark:text-gray-400">Kesulitan</th>
                                            </tr>
                                        </thead>
                                        <tbody className="divide-y divide-gray-200 dark:divide-gray-700">
                                            {Array.isArray(analytics.quiz_analytics) && analytics.quiz_analytics.length > 0 ? (
                                                analytics.quiz_analytics.map((quiz: any, index: number) => (
                                                    <tr key={index} className="hover:bg-gray-50 dark:hover:bg-gray-700/50 transition-colors">
                                                        <td className="px-4 md:px-6 py-4 text-sm font-medium text-gray-900 dark:text-white">{quiz.quiz_title}</td>
                                                        <td className="px-4 md:px-6 py-4 text-xs md:text-sm text-gray-600 dark:text-gray-400">{quiz.module_title}</td>
                                                        <td className="px-4 md:px-6 py-4 text-xs md:text-sm text-gray-900 dark:text-white">{quiz.total_attempts}</td>
                                                        <td className="px-4 md:px-6 py-4 text-xs md:text-sm text-gray-900 dark:text-white">{quiz.average_score}</td>
                                                        <td className="px-4 md:px-6 py-4 text-xs md:text-sm text-gray-900 dark:text-white">{quiz.pass_rate}%</td>
                                                        <td className="px-4 md:px-6 py-4">
                                                            <span className={`px-2 py-1 text-xs rounded-full ${
                                                                quiz.difficulty_rating === 'Easy'
                                                                    ? 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300'
                                                                    : quiz.difficulty_rating === 'Medium'
                                                                    ? 'bg-yellow-100 dark:bg-yellow-900/30 text-yellow-700 dark:text-yellow-300'
                                                                    : 'bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-300'
                                                            }`}>
                                                                {quiz.difficulty_rating}
                                                            </span>
                                                        </td>
                                                    </tr>
                                                ))
                                            ) : (
                                                <tr>
                                                    <td colSpan={6} className="px-6 py-8 text-center text-gray-500">
                                                        Belum ada data analisis
                                                    </td>
                                                </tr>
                                            )}
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </>
                    ) : (
                        <div className="text-center py-8">
                            <BarChart3 className="h-16 w-16 text-gray-400 mx-auto mb-4" />
                            <p className="text-gray-500">Belum ada data analisis</p>
                        </div>
                    )}
                </div>
            )}

            {/* Create/Edit/View Modal */}
            {showModal && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
                    <div className="bg-white dark:bg-gray-800 rounded-xl w-full max-w-6xl max-h-[90vh] overflow-y-auto">
                        <div className="sticky top-0 bg-white dark:bg-gray-800 p-4 md:p-6 border-b border-gray-200 dark:border-gray-700 z-10">
                            <div className="flex items-center justify-between">
                                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                                    {modalType === 'create' ? 'Buat Quiz Baru' :
                                     modalType === 'edit' ? 'Edit Quiz' : 'Detail Quiz'}
                                </h3>
                                <button
                                    onClick={() => setShowModal(false)}
                                    className="text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 transition-colors"
                                >
                                    <X className="h-6 w-6" />
                                </button>
                            </div>
                        </div>

                        <div className="p-4 md:p-6">
                            {modalType === 'view' ? (
                                <div className="space-y-6">
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                                Judul Quiz
                                            </label>
                                            <p className="text-gray-900 dark:text-white bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
                                                {quizForm.title || 'Tidak ada judul'}
                                            </p>
                                        </div>
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                                Modul
                                            </label>
                                            <p className="text-gray-900 dark:text-white bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
                                                {modules.find(m => m.id.toString() === quizForm.module_id)?.title || 'Tidak diketahui'}
                                            </p>
                                        </div>
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                                Waktu Pengerjaan
                                            </label>
                                            <p className="text-gray-900 dark:text-white bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
                                                {quizForm.time_limit || 30} menit
                                            </p>
                                        </div>
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                                Total Soal
                                            </label>
                                            <p className="text-gray-900 dark:text-white bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
                                                {quizForm.questions.length} soal
                                            </p>
                                        </div>
                                    </div>

                                    {quizForm.description && (
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                                Deskripsi
                                            </label>
                                            <p className="text-gray-900 dark:text-white bg-gray-50 dark:bg-gray-700 p-3 rounded-lg">
                                                {quizForm.description}
                                            </p>
                                        </div>
                                    )}

                                    <div>
                                        <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-4">
                                            Daftar Soal ({quizForm.questions.length})
                                        </label>
                                        <div className="space-y-4">
                                            {quizForm.questions.map((question, index) => (
                                                <div key={index} className="border border-gray-200 dark:border-gray-600 rounded-lg p-4 bg-gray-50 dark:bg-gray-700">
                                                    <h4 className="font-medium mb-3 text-gray-900 dark:text-white">
                                                        Soal {index + 1} ({question.points} poin)
                                                    </h4>
                                                    <p className="text-gray-700 dark:text-gray-300 mb-3">
                                                        {question.question}
                                                    </p>
                                                    {Array.isArray(question.options) && (
                                                        <div className="space-y-2">
                                                            {question.options.map((option, optIndex) => (
                                                                <div key={optIndex} className={`p-2 rounded ${
                                                                    String.fromCharCode(65 + optIndex) === question.correct_answer
                                                                        ? 'bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-300 border border-green-300 dark:border-green-700'
                                                                        : 'bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-600'
                                                                }`}>
                                                                    <span className="font-medium">
                                                                        {String.fromCharCode(65 + optIndex)}.
                                                                    </span> {option}
                                                                    {String.fromCharCode(65 + optIndex) === question.correct_answer && (
                                                                        <span className="ml-2 text-green-600 dark:text-green-400">✓ Jawaban Benar</span>
                                                                    )}
                                                                </div>
                                                            ))}
                                                        </div>
                                                    )}
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                </div>
                            ) : (
                                <div className="space-y-6">
                                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                                Judul Quiz <span className="text-red-500">*</span>
                                            </label>
                                            <input
                                                type="text"
                                                value={quizForm.title}
                                                onChange={(e) => setQuizForm(prev => ({...prev, title: e.target.value}))}
                                                className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                                                placeholder="Masukkan judul quiz..."
                                            />
                                        </div>
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                                Modul <span className="text-red-500">*</span>
                                            </label>
                                            <select
                                                value={quizForm.module_id}
                                                onChange={(e) => setQuizForm(prev => ({...prev, module_id: e.target.value}))}
                                                className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                                            >
                                                <option value="">Pilih Modul...</option>
                                                {modules.map(module => (
                                                    <option key={module.id} value={module.id}>{module.title}</option>
                                                ))}
                                            </select>
                                        </div>
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                                Waktu Pengerjaan (menit) <span className="text-red-500">*</span>
                                            </label>
                                            <input
                                                type="number"
                                                value={quizForm.time_limit}
                                                onChange={(e) => setQuizForm(prev => ({...prev, time_limit: parseInt(e.target.value) || 30}))}
                                                className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                                                min="5"
                                                max="180"
                                            />
                                        </div>
                                        <div>
                                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                                Total Soal
                                            </label>
                                            <input
                                                type="text"
                                                value={`${quizForm.questions.length} soal`}
                                                className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-gray-100 dark:bg-gray-700 text-gray-500"
                                                disabled
                                            />
                                        </div>
                                        <div className="md:col-span-2">
                                            <label className="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                                                Deskripsi
                                            </label>
                                            <textarea
                                                value={quizForm.description}
                                                onChange={(e) => setQuizForm(prev => ({...prev, description: e.target.value}))}
                                                className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg bg-white dark:bg-gray-800 text-gray-900 dark:text-white focus:ring-2 focus:ring-blue-500"
                                                rows={3}
                                                placeholder="Masukkan deskripsi quiz (opsional)..."
                                            />
                                        </div>
                                    </div>

                                    <div className="border-t border-gray-200 dark:border-gray-700 pt-6">
                                        <h4 className="text-lg font-medium mb-4 text-gray-900 dark:text-white">
                                            Soal Quiz ({quizForm.questions.length})
                                        </h4>

                                        {quizForm.questions.length > 0 && (
                                            <div className="mb-6">
                                                <h5 className="font-medium mb-3 text-gray-900 dark:text-white">Daftar Soal</h5>
                                                <QuestionList />
                                            </div>
                                        )}

                                        <div className="border border-gray-200 dark:border-gray-600 rounded-lg p-4 bg-gray-50 dark:bg-gray-700">
                                            <h5 className="font-medium mb-4 text-gray-900 dark:text-white">Tambah Soal Baru</h5>
                                            <QuestionEditor />
                                        </div>
                                    </div>
                                </div>
                            )}
                        </div>

                        <div className="sticky bottom-0 p-4 md:p-6 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700">
                            <div className="flex items-center justify-end gap-4">
                                <button
                                    onClick={() => setShowModal(false)}
                                    className="px-4 md:px-6 py-2 text-gray-600 dark:text-gray-400 border border-gray-300 dark:border-gray-600 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-600 transition-colors"
                                    >
                                    {modalType === 'view' ? 'Tutup' : 'Batal'}
                                </button>
                                {modalType !== 'view' && (
                                <button
                                onClick={handleSubmitQuiz}
                                disabled={!quizForm.title || !quizForm.module_id || quizForm.questions.length === 0}
                                className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white px-4 md:px-6 py-2 rounded-lg transition-colors"
                                >
                                <Save className="h-4 w-4" />
                                {modalType === 'create' ? 'Buat Quiz' : 'Simpan Perubahan'}
                                </button>
                                            )}
</div>
</div>
</div>
</div>
)}
{/* Result Detail Modal */}
            {selectedResultDetail && (
                <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
                    <div className="bg-white dark:bg-gray-800 rounded-xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
                        <div className="sticky top-0 bg-white dark:bg-gray-800 p-4 md:p-6 border-b border-gray-200 dark:border-gray-700 z-10">
                            <div className="flex items-center justify-between">
                                <h3 className="text-lg font-semibold text-gray-900 dark:text-white">
                                    Detail Hasil Quiz
                                </h3>
                                <button
                                    onClick={() => setSelectedResultDetail(null)}
                                    className="text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 transition-colors"
                                >
                                    <X className="h-6 w-6" />
                                </button>
                            </div>
                        </div>

                        <div className="p-4 md:p-6 space-y-6">
                            {/* Student Info */}
                            <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                    <div>
                                        <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Nama Mahasiswa</p>
                                        <p className="font-semibold text-gray-900 dark:text-white">{selectedResultDetail.studentName}</p>
                                    </div>
                                    <div>
                                        <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">NIM</p>
                                        <p className="font-semibold text-gray-900 dark:text-white">{selectedResultDetail.nim}</p>
                                    </div>
                                    <div>
                                        <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Quiz</p>
                                        <p className="font-semibold text-gray-900 dark:text-white">{selectedResultDetail.quizTitle}</p>
                                    </div>
                                    <div>
                                        <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Waktu Selesai</p>
                                        <p className="font-semibold text-gray-900 dark:text-white">
                                            {new Date(selectedResultDetail.completedAt).toLocaleString('id-ID')}
                                        </p>
                                    </div>
                                </div>
                            </div>

                            {/* Score */}
                            <div className="grid grid-cols-2 gap-4">
                                <div className={`p-6 rounded-lg border-2 ${
                                    selectedResultDetail.score >= 80
                                        ? 'bg-green-50 dark:bg-green-900/20 border-green-300 dark:border-green-700'
                                        : selectedResultDetail.score >= 60
                                        ? 'bg-yellow-50 dark:bg-yellow-900/20 border-yellow-300 dark:border-yellow-700'
                                        : 'bg-red-50 dark:bg-red-900/20 border-red-300 dark:border-red-700'
                                }`}>
                                    <Award className={`h-8 w-8 mx-auto mb-2 ${
                                        selectedResultDetail.score >= 80
                                            ? 'text-green-600'
                                            : selectedResultDetail.score >= 60
                                            ? 'text-yellow-600'
                                            : 'text-red-600'
                                    }`} />
                                    <p className="text-center text-sm text-gray-600 dark:text-gray-400 mb-1">Skor Akhir</p>
                                    <p className={`text-center text-4xl font-bold ${
                                        selectedResultDetail.score >= 80
                                            ? 'text-green-600'
                                            : selectedResultDetail.score >= 60
                                            ? 'text-yellow-600'
                                            : 'text-red-600'
                                    }`}>
                                        {selectedResultDetail.score}
                                    </p>
                                </div>

                                <div className="bg-purple-50 dark:bg-purple-900/20 border-2 border-purple-300 dark:border-purple-700 p-6 rounded-lg">
                                    <Target className="h-8 w-8 text-purple-600 mx-auto mb-2" />
                                    <p className="text-center text-sm text-gray-600 dark:text-gray-400 mb-1">Poin Diperoleh</p>
                                    <p className="text-center text-4xl font-bold text-purple-600">
                                        +{selectedResultDetail.pointsEarned}
                                    </p>
                                </div>
                            </div>

                            {/* Status */}
                            <div className={`p-4 rounded-lg border ${
                                selectedResultDetail.score >= 60
                                    ? 'bg-green-50 dark:bg-green-900/20 border-green-200 dark:border-green-800'
                                    : 'bg-red-50 dark:bg-red-900/20 border-red-200 dark:border-red-800'
                            }`}>
                                <div className="flex items-center gap-3">
                                    {selectedResultDetail.score >= 60 ? (
                                        <CheckCircle className="h-6 w-6 text-green-600" />
                                    ) : (
                                        <AlertCircle className="h-6 w-6 text-red-600" />
                                    )}
                                    <div>
                                        <p className={`font-semibold ${
                                            selectedResultDetail.score >= 60 ? 'text-green-800 dark:text-green-300' : 'text-red-800 dark:text-red-300'
                                        }`}>
                                            {selectedResultDetail.score >= 60 ? '✓ Lulus' : '✗ Tidak Lulus'}
                                        </p>
                                        <p className="text-sm text-gray-600 dark:text-gray-400">
                                            {selectedResultDetail.score >= 60
                                                ? 'Mahasiswa berhasil mencapai nilai minimum kelulusan'
                                                : 'Mahasiswa belum mencapai nilai minimum kelulusan (60)'
                                            }
                                        </p>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="sticky bottom-0 p-4 md:p-6 border-t border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-700">
                            <button
                                onClick={() => setSelectedResultDetail(null)}
                                className="w-full px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
                            >
                                Tutup
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </div>
    </AppLayout>

);
};

export default InstructorQuizManagement;
