import { NavFooter } from '@/components/nav-footer';
import { NavMain } from '@/components/nav-main';
import { NavUser } from '@/components/nav-user';
import { Sidebar, SidebarContent, SidebarFooter, SidebarHeader, SidebarMenu, SidebarMenuButton, SidebarMenuItem } from '@/components/ui/sidebar';
import { type NavItem } from '@/types';
import { Link, usePage } from '@inertiajs/react';
import { BookOpen, Code, FilePenLine, Folder, GraduationCap, House, LayoutDashboard, Trophy, Users, BookMarked } from 'lucide-react';
import AppLogo from './app-logo';

// Student Navigation Items
const studentNavItems: NavItem[] = [
    {
        title: 'Dashboard',
        href: '/dashboard',
        icon: House,
    },
    {
        title: 'Leaderboard',
        href: '/leaderboard',
        icon: Trophy,
    },
    {
        title: 'Compiler',
        href: '/compiler',
        icon: Code,
    },
    {
        title: 'ManualBook',
        href: '/manual-book',
        icon: BookMarked,
    },
];

// Instructor Navigation Items
const instructorNavItems: NavItem[] = [
    {
        title: 'Dashboard',
        href: '/instructor/dashboard',
        icon: LayoutDashboard,
    },
    {
        title: 'Modul',
        href: '/instructor/modules',
        icon: BookMarked,
    },
    {
        title: 'Kelas',
        href: '/instructor/classes',
        icon: Users,
    },
    {
        title: 'Quiz',
        href: '/instructor/quiz',
        icon: FilePenLine,
    },
    {
        title: 'Praktikum',
        href: '/instructor/praktikum',
        icon: GraduationCap,
    },
    {
        title: 'Leaderboard',
        href: '/leaderboard',
        icon: Trophy,
    },
    {
        title: 'Compiler',
        href: '/compiler',
        icon: Code,
    },
    {
        title: 'ManualBook',
        href: '/instructor/manual-book',
        icon: BookMarked,
    },
];

const footerNavItems: NavItem[] = [

];

export function AppSidebar() {
    // Get current user from Inertia shared data
    const props = usePage().props as Partial<{ auth: { user: { role: string } } }>;
    const role = props.auth?.user?.role ?? 'student';

    const mainNavItems = role === 'instructor' ? instructorNavItems : studentNavItems;
    const dashboardLink = role === 'instructor' ? '/instructor/dashboard' : '/dashboard';

    return (
        <Sidebar collapsible="icon" variant="inset">
            <SidebarHeader>
                <SidebarMenu>
                    <SidebarMenuItem>
                        <SidebarMenuButton size="lg" asChild>
                            <Link href={dashboardLink} prefetch>
                                <AppLogo />
                            </Link>
                        </SidebarMenuButton>
                    </SidebarMenuItem>
                </SidebarMenu>
            </SidebarHeader>

            <SidebarContent>
                <NavMain items={mainNavItems} />
            </SidebarContent>

            <SidebarFooter>
                <NavFooter items={footerNavItems} className="mt-auto" />
                <NavUser />
            </SidebarFooter>
        </Sidebar>
    );
}
